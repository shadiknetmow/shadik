
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Transaction, TransactionType, Debt, DebtType, DebtVersion, TransactionVersion, User, 
  Person, PersonVersion, PersonLedgerEntry, PersonLedgerEntryType, DebtFormSubmitData, 
  FormPurpose, AuthFormMode, BudgetCategory, Budget, BudgetPeriod
} from './types';
import { BN_UI_TEXT, LOCAL_STORAGE_KEYS, TRANSACTION_DESCRIPTION_SUGGESTIONS_BN } from './constants';
import Header from './components/Header';
import Summary from './components/Summary';
import TransactionForm from './components/TransactionForm';
import TransactionList from './components/TransactionList';
import AITipCard from './components/AITipCard';
import EditTransactionModal from './components/EditTransactionModal';
import DebtForm from './components/DebtForm';
import DebtList from './components/DebtList';
import AuthForm from './components/AuthForm';
import EditDebtModal from './components/EditDebtModal';
import TransactionHistoryModal from './components/TransactionHistoryModal';
import DebtHistoryModal from './components/DebtHistoryModal';
import Modal from './components/Modal';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import ReportModal from './components/ReportModal'; 

// Person Management Components
import PersonList from './components/PersonList';
import PersonForm from './components/PersonForm';
import PersonHistoryModal from './components/PersonHistoryModal';
import SelectPersonModal from './components/SelectPersonModal';
import PersonDebtsHistoryModal from './components/PersonDebtsHistoryModal'; 
import AddPersonLedgerEntryModal from './components/AddPersonLedgerEntryModal';
import PersonLedgerHistoryModal from './components/PersonLedgerHistoryModal';
import PersonFinancialOverviewModal from './components/PersonFinancialOverviewModal'; 
import ReceivablePersonsModal, { ReceivablePersonData } from './components/ReceivablePersonsModal';
import PayablePersonsModal, { PayablePersonData } from './components/PayablePersonsModal';
import ManageSuggestionsModal from './components/ManageSuggestionsModal';
// Budgeting Components
import BudgetSetupModal from './components/BudgetSetupModal';


import * as apiService from './apiService'; 

const AppContent: React.FC = () => {
  const { 
    currentUser, 
    logout: authLogout, 
    isAuthLoading: isAuthContextLoading, 
    authError: authContextError           
  } = useAuth(); 
  
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [debts, setDebts] = useState<Debt[]>([]);
  const [persons, setPersons] = useState<Person[]>([]);
  const [personLedgerEntries, setPersonLedgerEntries] = useState<PersonLedgerEntry[]>([]);
  const [userCustomSuggestions, setUserCustomSuggestions] = useState<string[]>([]);
  const [budgetCategories, setBudgetCategories] = useState<BudgetCategory[]>([]);
  const [budgets, setBudgets] = useState<Budget[]>([]);

  const [isLoadingData, setIsLoadingData] = useState(false); 
  const [appError, setAppError] = useState<string | null>(null);

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [isTransactionEditHistoryModalOpen, setIsTransactionEditHistoryModalOpen] = useState(false);
  const [viewingTransactionEditHistoryFor, setViewingTransactionEditHistoryFor] = useState<Transaction | null>(null);
  const [isManageSuggestionsModalOpen, setIsManageSuggestionsModalOpen] = useState(false);

  const [isEditDebtModalOpen, setIsEditDebtModalOpen] = useState(false);
  const [editingDebt, setEditingDebt] = useState<Debt | null>(null);
  const [isDebtEditHistoryModalOpen, setIsDebtEditHistoryModalOpen] = useState(false);
  const [viewingDebtEditHistoryFor, setViewingDebtEditHistoryFor] = useState<Debt | null>(null);
  
  const [isManagePersonsModalOpen, setIsManagePersonsModalOpen] = useState(false);
  const [isPersonFormModalOpen, setIsPersonFormModalOpen] = useState(false);
  const [editingPerson, setEditingPerson] = useState<Person | null>(null);
  const [isPersonHistoryModalOpen, setIsPersonHistoryModalOpen] = useState(false);
  const [viewingPersonHistoryFor, setViewingPersonHistoryFor] = useState<Person | null>(null);
  const [isSelectPersonModalOpen, setIsSelectPersonModalOpen] = useState(false);
  const [selectPersonCallback, setSelectPersonCallback] = useState<(personId: string) => void>(() => () => {});
  const [isPersonDebtsHistoryModalOpen, setIsPersonDebtsHistoryModalOpen] = useState(false);
  const [viewingPersonForDebtsHistory, setViewingPersonForDebtsHistory] = useState<Person | null>(null);

  const [isAddLedgerEntryModalOpen, setIsAddLedgerEntryModalOpen] = useState(false);
  const [isPersonLedgerHistoryModalOpen, setIsPersonLedgerHistoryModalOpen] = useState(false);
  const [selectedPersonForLedger, setSelectedPersonForLedger] = useState<Person | null>(null);

  const [isPersonFinancialOverviewModalOpen, setIsPersonFinancialOverviewModalOpen] = useState(false);
  const [viewingPersonForOverview, setViewingPersonForOverview] = useState<Person | null>(null);

  const [isReceivablePersonsModalOpen, setIsReceivablePersonsModalOpen] = useState(false);
  const [isPayablePersonsModalOpen, setIsPayablePersonsModalOpen] = useState(false);

  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isBudgetSetupModalOpen, setIsBudgetSetupModalOpen] = useState(false);


  const [showAuthForm, setShowAuthForm] = useState<AuthFormMode | null>(null);

  const [isAddTransactionModalOpen, setIsAddTransactionModalOpen] = useState(false);
  const [isDebtManagementModalOpen, setIsDebtManagementModalOpen] = useState(false);
  const [isViewTransactionsModalOpen, setIsViewTransactionsModalOpen] = useState(false);

  const loadAppData = useCallback(async () => {
    if (currentUser && currentUser.email) {
      setIsLoadingData(true);
      setAppError(null); 
      try {
        const [
          fetchedTransactions,
          fetchedDebts,
          fetchedPersons,
          fetchedLedgerEntries,
          fetchedSuggestions,
          fetchedBudgetCategories,
          fetchedBudgets,
        ] = await Promise.all([
          apiService.fetchRecords<Transaction>('transactions', currentUser.email),
          apiService.fetchRecords<Debt>('debts', currentUser.email),
          apiService.fetchRecords<Person>('persons', currentUser.email),
          apiService.fetchRecords<PersonLedgerEntry>('person_ledger_entries', currentUser.email),
          apiService.fetchUserSuggestions(currentUser.email),
          apiService.fetchRecords<BudgetCategory>('budgetCategories', currentUser.email),
          apiService.fetchRecords<Budget>('budgets', currentUser.email),
        ]);
        
        setTransactions(fetchedTransactions); 
        const migratedDebts = fetchedDebts.map(d => { 
          if ((d as any).amount !== undefined && d.originalAmount === undefined) {
            return {
              ...d,
              originalAmount: (d as any).amount,
              remainingAmount: d.isSettled ? 0 : (d as any).amount,
            };
          }
          return d;
        });
        setDebts(migratedDebts);
        setPersons(fetchedPersons); 
        setPersonLedgerEntries(fetchedLedgerEntries); 
        setUserCustomSuggestions(fetchedSuggestions);
        setBudgetCategories(fetchedBudgetCategories);
        setBudgets(fetchedBudgets);

      } catch (error: any) {
        console.error("Error loading app data from API:", error);
        setAppError(`তথ্য লোড করতে সমস্যা হয়েছে: ${error.message}. এটি ডেটাবেস কলামের সমস্যার কারণে হতে পারে।`);
      } finally {
        setIsLoadingData(false);
      }
    } else {
      setTransactions([]);
      setDebts([]);
      setPersons([]);
      setPersonLedgerEntries([]);
      setUserCustomSuggestions([]);
      setBudgetCategories([]);
      setBudgets([]);
      setIsLoadingData(false); 
    }
  }, [currentUser]);

  useEffect(() => {
    if (isAuthContextLoading) {
      setIsLoadingData(true); 
      return;
    }

    if (authContextError) {
      setAppError(`গুরুত্বপূর্ণ: ডেটাবেস সেটআপ বা প্রমাণীকরণে সমস্যা হয়েছে। অনুগ্রহ করে অ্যাপ অ্যাডমিনের সাথে যোগাযোগ করুন। বিস্তারিত: ${authContextError}`);
      setIsLoadingData(false); 
      setTransactions([]); 
      setDebts([]);
      setPersons([]);
      setPersonLedgerEntries([]);
      setUserCustomSuggestions([]);
      setBudgetCategories([]);
      setBudgets([]);
      return; 
    }
    loadAppData();
  }, [loadAppData, isAuthContextLoading, authContextError]);


  const allTransactionSuggestions = useMemo(() => {
    const combined = [...TRANSACTION_DESCRIPTION_SUGGESTIONS_BN, ...userCustomSuggestions];
    return [...new Set(combined)].sort((a, b) => a.localeCompare(b, 'bn-BD'));
  }, [userCustomSuggestions]);

  const addUserCustomSuggestion = async (suggestion: string) => {
    if (!currentUser || !currentUser.email) return;
    const trimmed = suggestion.trim();
    if (trimmed && !userCustomSuggestions.includes(trimmed) && !TRANSACTION_DESCRIPTION_SUGGESTIONS_BN.includes(trimmed)) {
      try {
        await apiService.addUserSuggestion(currentUser.email, trimmed);
        setUserCustomSuggestions(prev => [...prev, trimmed].sort((a, b) => a.localeCompare(b, 'bn-BD')));
        alert(BN_UI_TEXT.SUGGESTION_ADDED_SUCCESS);
      } catch (error: any) {
        alert(`পরামর্শ যোগ করতে সমস্যা হয়েছে: ${error.message}`);
      }
    } else if (trimmed) {
      alert(BN_UI_TEXT.SUGGESTION_EXISTS_ERROR);
    }
  };

  const editUserCustomSuggestion = async (oldSuggestion: string, newSuggestion: string) => {
    if (!currentUser || !currentUser.email) return;
    const trimmedNew = newSuggestion.trim();
    if (!trimmedNew) {
      alert(BN_UI_TEXT.SUGGESTION_EXISTS_ERROR);
      return;
    }
    if (userCustomSuggestions.includes(trimmedNew) || TRANSACTION_DESCRIPTION_SUGGESTIONS_BN.includes(trimmedNew)) {
        if (trimmedNew !== oldSuggestion) {
            alert(BN_UI_TEXT.SUGGESTION_EXISTS_ERROR);
            return;
        }
    }
    try {
      await apiService.deleteUserSuggestion(currentUser.email, oldSuggestion);
      await apiService.addUserSuggestion(currentUser.email, trimmedNew);
      setUserCustomSuggestions(prev => prev.map(s => s === oldSuggestion ? trimmedNew : s).sort((a, b) => a.localeCompare(b, 'bn-BD')));
      alert(BN_UI_TEXT.SUGGESTION_UPDATED_SUCCESS);
    } catch (error: any) {
       alert(`পরামর্শ আপডেট করতে সমস্যা হয়েছে: ${error.message}`);
    }
  };

  const deleteUserCustomSuggestion = async (suggestion: string) => {
    if (!currentUser || !currentUser.email) return;
    if (window.confirm(BN_UI_TEXT.CONFIRM_DELETE_SUGGESTION_MSG)) {
      try {
        await apiService.deleteUserSuggestion(currentUser.email, suggestion);
        setUserCustomSuggestions(prev => prev.filter(s => s !== suggestion));
        alert(BN_UI_TEXT.SUGGESTION_DELETED_SUCCESS);
      } catch (error: any) {
        alert(`পরামর্শ মুছতে সমস্যা হয়েছে: ${error.message}`);
      }
    }
  };

  const handleOpenManageSuggestionsModal = () => setIsManageSuggestionsModalOpen(true);
  const handleCloseManageSuggestionsModal = () => setIsManageSuggestionsModalOpen(false);

  const addTransaction = useCallback(
    async (
      transactionData: Omit<Transaction, 'id' | 'date' | 'originalDate' | 'lastModified' | 'userId' | 'editHistory' | 'linkedLedgerEntryId' | 'isDeleted' | 'deletedAt'> & { date?: string },
      linkedLedgerEntryId?: string
    ) => {
      if (!currentUser || !currentUser.email) return;
      const now = new Date().toISOString();
      const transactionDate = transactionData.date || now;
      const id = Date.now().toString() + Math.random().toString(36).substring(2, 9);

      const newTransactionBase: Omit<Transaction, 'id' | 'userId' | 'editHistory'> = {
        description: transactionData.description,
        amount: transactionData.amount,
        type: transactionData.type,
        date: transactionDate,
        lastModified: now,
        linkedLedgerEntryId: linkedLedgerEntryId,
        isDeleted: false,
        deletedAt: undefined,
      };

      const firstVersionSnapshot: TransactionVersion['snapshot'] = {
        description: newTransactionBase.description,
        amount: newTransactionBase.amount,
        type: newTransactionBase.type,
        date: newTransactionBase.date,
        linkedLedgerEntryId: newTransactionBase.linkedLedgerEntryId,
        isDeleted: false,
      };

      const firstVersion: TransactionVersion = {
        timestamp: now, action: 'created', userId: currentUser.email, snapshot: firstVersionSnapshot,
      };
      
      const newTransaction: Transaction = {
        ...newTransactionBase, id, userId: currentUser.email, 
        editHistory: [firstVersion],
      };
      try {
        await apiService.insertRecord('transactions', currentUser.email, newTransaction);
        setTransactions(prevTransactions => [...prevTransactions, newTransaction]);
      } catch (error: any) {
        alert(`লেনদেন যোগ করতে সমস্যা হয়েছে: ${error.message}`);
      }
    },
    [currentUser]
  );
  
  const recalculateLedgerBalancesForPerson = useCallback((personId: string, currentEntries: PersonLedgerEntry[]): PersonLedgerEntry[] => {
    const personEntriesForRecalc = currentEntries
      .filter(entry => entry.personId === personId) 
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    let runningBalance = 0;
    const updatedPersonEntries = personEntriesForRecalc.map(entry => {
      if (entry.type === PersonLedgerEntryType.DEBIT) { 
        runningBalance += entry.amount;
      } else { 
        runningBalance -= entry.amount;
      }
      return { ...entry, balanceAfterEntry: runningBalance };
    });
    
    if (currentUser && currentUser.email) {
        updatedPersonEntries.forEach(async (entry) => {
            try {
                await apiService.updateRecord('person_ledger_entries', currentUser.email!, { balanceAfterEntry: entry.balanceAfterEntry }, `id = '${entry.id}'`);
            } catch (error) {
                console.error(`Failed to update balance for ledger entry ${entry.id}:`, error);
            }
        });
    }

    return currentEntries.map(entry => {
      if (entry.personId === personId) {
        const foundUpdated = updatedPersonEntries.find(upe => upe.id === entry.id);
        return foundUpdated || entry; 
      }
      return entry;
    });
  }, [currentUser]);
  
  const addPersonLedgerEntry = useCallback(async (data: {personId: string, type: PersonLedgerEntryType, amount: number, description: string, date: string}) => {
    if (!currentUser || !currentUser.email) return;
    const now = new Date().toISOString();
    const id = 'pledger-' + Date.now().toString() + Math.random().toString(36).substring(2, 9);

    const newLedgerEntryData: Omit<PersonLedgerEntry, 'balanceAfterEntry' | 'userId'> = {
      ...data, id,
    };
    
    const tempEntryForBalanceCalc: PersonLedgerEntry = {...newLedgerEntryData, userId: currentUser.email, balanceAfterEntry: 0 };
    const entriesForBalanceCalc = [...personLedgerEntries, tempEntryForBalanceCalc];
    const updatedEntriesForPerson = recalculateLedgerBalancesForPerson(data.personId, entriesForBalanceCalc);
    const finalNewEntry = updatedEntriesForPerson.find(e => e.id === id);

    if (!finalNewEntry) {
        alert("হিসাবের এন্ট্রি যোগ করতে একটি অভ্যন্তরীণ ত্রুটি হয়েছে।");
        return;
    }

    try {
      await apiService.insertRecord('person_ledger_entries', currentUser.email, finalNewEntry); 
      setPersonLedgerEntries(prevEntries => {
        const entriesWithNew = [...prevEntries.filter(e => e.id !== id), finalNewEntry];
        return recalculateLedgerBalancesForPerson(data.personId, entriesWithNew);
      });

      let paymentAmountToApplyToDebts = data.amount;
      const person = persons.find(p => p.id === data.personId);
      const personName = person ? person.name : BN_UI_TEXT.UNKNOWN_PERSON;

      const debtsToUpdate: Debt[] = [];
      const updatedDebtsLocally = debts.map(d => {
          if (d.personId === data.personId && !d.isSettled && d.remainingAmount > 0 &&
              (data.type === PersonLedgerEntryType.CREDIT ? d.type === DebtType.RECEIVABLE : d.type === DebtType.PAYABLE)) {
              
              if (paymentAmountToApplyToDebts <= 0) return d;
              const amountAppliedToThisDebt = Math.min(paymentAmountToApplyToDebts, d.remainingAmount);
              if (amountAppliedToThisDebt > 0) {
                  const updatedDebt = { ...d };
                  updatedDebt.remainingAmount -= amountAppliedToThisDebt;
                  updatedDebt.lastModified = now;
                  let debtHistoryDescUpdate = "";
                  let transactionDesc = "";
                  if (data.type === PersonLedgerEntryType.CREDIT) {
                      transactionDesc = `${personName}-এর পাওনা (${d.description}) বাবদ লেজার থেকে জমা (${data.description}): ${BN_UI_TEXT.BDT_SYMBOL}${amountAppliedToThisDebt.toFixed(2)}`;
                      addTransaction({ description: transactionDesc, amount: amountAppliedToThisDebt, type: TransactionType.INCOME, date: data.date }, finalNewEntry.id);
                      debtHistoryDescUpdate = BN_UI_TEXT.DEBT_HISTORY_PAID_BY_LEDGER_CREDIT.replace("{amount}", amountAppliedToThisDebt.toFixed(2));
                  } else {
                      transactionDesc = `${personName}-কে দেনা (${d.description}) বাবদ লেজার থেকে পরিশোধ (${data.description}): ${BN_UI_TEXT.BDT_SYMBOL}${amountAppliedToThisDebt.toFixed(2)}`;
                      addTransaction({ description: transactionDesc, amount: amountAppliedToThisDebt, type: TransactionType.EXPENSE, date: data.date }, finalNewEntry.id);
                      debtHistoryDescUpdate = BN_UI_TEXT.DEBT_HISTORY_PAID_BY_LEDGER_DEBIT.replace("{amount}", amountAppliedToThisDebt.toFixed(2));
                  }
                  const newHistoryEntrySnapshot: DebtVersion['snapshot'] = {
                      personId: updatedDebt.personId, originalAmount: updatedDebt.originalAmount, remainingAmount: updatedDebt.remainingAmount,
                      description: `${updatedDebt.description} ${debtHistoryDescUpdate}`, type: updatedDebt.type, dueDate: updatedDebt.dueDate,
                      isSettled: updatedDebt.remainingAmount <= 0, creationDate: updatedDebt.creationDate,
                      settledDate: updatedDebt.remainingAmount <= 0 ? data.date : updatedDebt.settledDate,
                  };
                  if (updatedDebt.remainingAmount <= 0) {
                      updatedDebt.isSettled = true;
                      updatedDebt.settledDate = data.date;
                      newHistoryEntrySnapshot.description = `${updatedDebt.description} (লেজার এন্ট্রি দ্বারা সম্পূর্ণরূপে পরিশোধিত ${debtHistoryDescUpdate})`;
                  }
                  const newHistoryEntry: DebtVersion = {
                      timestamp: now, action: 'updated', userId: currentUser.email!, snapshot: newHistoryEntrySnapshot,
                  };
                  updatedDebt.editHistory = [...(updatedDebt.editHistory || []), newHistoryEntry];
                  paymentAmountToApplyToDebts -= amountAppliedToThisDebt;
                  debtsToUpdate.push(updatedDebt);
                  return updatedDebt;
              }
          }
          return d;
      });
      setDebts(updatedDebtsLocally);
      for (const debtToSave of debtsToUpdate) {
          await apiService.updateRecord('debts', currentUser.email!, debtToSave, `id = '${debtToSave.id}'`);
      }
    } catch (error: any) {
      alert(`হিসাবের এন্ট্রি যোগ করতে সমস্যা হয়েছে: ${error.message}`);
    }
  }, [currentUser, persons, addTransaction, recalculateLedgerBalancesForPerson, personLedgerEntries, debts]);

  const deletePersonLedgerEntry = useCallback(async (entryId: string, personId: string) => {
    if (!currentUser || !currentUser.email) return;
    try {
      await apiService.deleteRecord('person_ledger_entries', currentUser.email, `id = '${entryId}'`); 
      setPersonLedgerEntries(prevEntries => {
        const remainingEntries = prevEntries.filter(entry => entry.id !== entryId);
        return recalculateLedgerBalancesForPerson(personId, remainingEntries);
      });
      alert(BN_UI_TEXT.LEDGER_ENTRY_DELETED_SUCCESS);
    } catch (error: any) {
      alert(`এন্ট্রি মুছতে সমস্যা হয়েছে: ${error.message}`);
    }
  }, [currentUser, recalculateLedgerBalancesForPerson, personLedgerEntries]);


  const getLedgerOnlyNetBalance = useCallback((personId: string): number => {
    const personEntries = personLedgerEntries
      .filter(entry => entry.personId === personId) 
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()); 
    return personEntries.length > 0 ? personEntries[0].balanceAfterEntry : 0;
  }, [personLedgerEntries]);

  const calculateCompositePersonBalance = useCallback((personId: string): number => { 
    const ledgerOnlyBalance = getLedgerOnlyNetBalance(personId); 
    let netUnsettledDebtEffect = 0;
    const personUnsettledDebts = debts.filter(debt => debt.personId === personId && !debt.isSettled && debt.remainingAmount > 0); 
    personUnsettledDebts.forEach(debt => {
      if (debt.type === DebtType.RECEIVABLE) { 
        netUnsettledDebtEffect += debt.remainingAmount;
      } else { 
        netUnsettledDebtEffect -= debt.remainingAmount;
      }
    });
    return ledgerOnlyBalance + netUnsettledDebtEffect;
  }, [debts, getLedgerOnlyNetBalance]); 


  const addPerson = useCallback(async (personData: Omit<Person, 'id' | 'userId' | 'createdAt' | 'lastModified' | 'editHistory'>): Promise<Person> => {
    if (!currentUser || !currentUser.email) throw new Error("User not logged in");
    const now = new Date().toISOString();
    const id = 'person-' + Date.now().toString() + Math.random().toString(36).substring(2, 9);
    
    const newPerson: Person = {
      ...personData, id, userId: currentUser.email, 
      createdAt: now, lastModified: now,
      editHistory: [{
        timestamp: now, action: 'created', userId: currentUser.email, 
        snapshot: { ...personData }
      }]
    };
    try {
        await apiService.insertRecord('persons', currentUser.email, newPerson); 
        setPersons(prev => [...prev, newPerson]);
        return newPerson;
    } catch (error: any) {
        alert(`নতুন ব্যক্তি যোগ করতে সমস্যা হয়েছে: ${error.message}`); 
        throw error;
    }
  }, [currentUser]);

  const updatePerson = useCallback(async (updatedPersonData: Omit<Person, 'id' | 'userId' | 'createdAt' | 'lastModified' | 'editHistory'>, personId: string) => {
    if (!currentUser || !currentUser.email) return;
    const now = new Date().toISOString();
    let personToUpdate: Person | undefined;

    setPersons(prev => prev.map(p => {
      if (p.id === personId) {
        const updatedPersonCore = { ...p, ...updatedPersonData, lastModified: now };
        const { id, userId, createdAt, lastModified, editHistory, ...snapshotData } = updatedPersonCore;
        const newVersion: PersonVersion = {
          timestamp: now, action: 'updated', userId: currentUser!.email, 
          snapshot: {...snapshotData } 
        };
        personToUpdate = { ...updatedPersonCore, userId: p.userId, editHistory: [...p.editHistory, newVersion] };
        return personToUpdate;
      }
      return p;
    }));

    if (personToUpdate) {
        try {
            const { id, userId, createdAt, ...dataToSet } = personToUpdate; 
            await apiService.updateRecord('persons', currentUser.email, dataToSet, `id = '${personId}'`);
            alert(BN_UI_TEXT.PERSON_UPDATED_SUCCESS);
            setIsPersonFormModalOpen(false); 
            setEditingPerson(null);
        } catch (error: any) {
            alert(`ব্যক্তির তথ্য আপডেট করতে সমস্যা হয়েছে: ${error.message}`);
            if (!authContextError && !isAuthContextLoading) loadAppData();
        }
    }
  }, [currentUser, loadAppData, authContextError, isAuthContextLoading]);

  const deletePerson = useCallback(async (personId: string) => {
    if (!currentUser || !currentUser.email) return;
    if (window.confirm(BN_UI_TEXT.CONFIRM_DELETE_PERSON_MSG)) {
        try {
            await apiService.deleteRecord('persons', currentUser.email, `id = '${personId}'`); 
            setPersons(prev => prev.filter(p => p.id !== personId));
            alert(BN_UI_TEXT.PERSON_DELETED_SUCCESS);
        } catch (error: any) {
            alert(`ব্যক্তি মুছতে সমস্যা হয়েছে: ${error.message}`);
        }
    }
  }, [currentUser]);

  const handleOpenEditModal = (transaction: Transaction) => { setEditingTransaction(transaction); setIsEditModalOpen(true); };
  const handleCloseEditModal = () => { setEditingTransaction(null); setIsEditModalOpen(false); };

  const handleSaveTransaction = async (updatedTransactionDataFromModal: Transaction) => {
     if (!currentUser || !currentUser.email || !editingTransaction) return;
    const now = new Date().toISOString();
    
    const updatedTransaction: Transaction = {
      ...editingTransaction, 
      description: updatedTransactionDataFromModal.description,
      amount: updatedTransactionDataFromModal.amount,
      type: updatedTransactionDataFromModal.type,
      date: updatedTransactionDataFromModal.date,
      originalDate: editingTransaction.originalDate || editingTransaction.date, 
      lastModified: now,
      userId: editingTransaction.userId,
      isDeleted: updatedTransactionDataFromModal.isDeleted, // Preserve existing soft-delete status
      deletedAt: updatedTransactionDataFromModal.deletedAt, 
    };
    
    const newVersionSnapshot: TransactionVersion['snapshot'] = {
        description: updatedTransaction.description,
        amount: updatedTransaction.amount,
        type: updatedTransaction.type,
        date: updatedTransaction.date,
        originalDate: updatedTransaction.originalDate,
        linkedLedgerEntryId: updatedTransaction.linkedLedgerEntryId,
        isDeleted: updatedTransaction.isDeleted,
        deletedAt: updatedTransaction.deletedAt,
    };
    const newVersion: TransactionVersion = {
        timestamp: now, action: 'updated', userId: currentUser.email, snapshot: newVersionSnapshot,
    };
    const finalTransactionToSave: Transaction = {
        ...updatedTransaction,
        editHistory: [...(editingTransaction.editHistory || []), newVersion]
    };
    
    const { id: transactionId, userId: ownerUserId, ...dataToSet } = finalTransactionToSave; 
    try {
        await apiService.updateRecord('transactions', currentUser.email, dataToSet, `id = '${finalTransactionToSave.id}'`);
        setTransactions(prevTransactions =>
          prevTransactions.map(t => (t.id === finalTransactionToSave.id ? finalTransactionToSave : t))
        );
        alert(BN_UI_TEXT.TRANSACTION_UPDATED);
        handleCloseEditModal();
    } catch (error: any) {
        alert(`লেনদেন আপডেট করতে সমস্যা হয়েছে: ${error.message}`);
    }
  };

  const deleteTransaction = useCallback(async (id: string) => {
    if (!currentUser || !currentUser.email) return;

    const transactionToDelete = transactions.find(t => t.id === id);
    if (!transactionToDelete) {
      console.error("Transaction to delete not found in local state.");
      return;
    }

    if (window.confirm(BN_UI_TEXT.CONFIRM_DELETE_MSG)) {
      const now = new Date().toISOString();
      
      // Create a snapshot for the 'deleted' action
      const deletedVersionSnapshot: TransactionVersion['snapshot'] = {
        // Copy all relevant fields from the transaction, then mark as deleted
        date: transactionToDelete.date,
        description: transactionToDelete.description,
        amount: transactionToDelete.amount,
        type: transactionToDelete.type,
        originalDate: transactionToDelete.originalDate,
        linkedLedgerEntryId: transactionToDelete.linkedLedgerEntryId,
        isDeleted: true, // Mark as deleted in the snapshot
        deletedAt: now,    // Record deletion time in the snapshot
      };

      const deleteVersion: TransactionVersion = {
        timestamp: now,
        action: 'deleted',
        userId: currentUser.email,
        snapshot: deletedVersionSnapshot,
      };

      const updatedTransactionForSoftDelete: Partial<Transaction> & { editHistory: TransactionVersion[], lastModified: string } = {
        isDeleted: true,
        deletedAt: now,
        lastModified: now,
        editHistory: [...(transactionToDelete.editHistory || []), deleteVersion],
      };
      
      // Exclude id and userId for the update payload
      const { id: txId, userId: txUserId, ...dataToSet } = { ...transactionToDelete, ...updatedTransactionForSoftDelete};

      try {
        await apiService.updateRecord('transactions', currentUser.email, dataToSet, `id = '${id}'`);
        setTransactions(prevTransactions => prevTransactions.filter(t => t.id !== id)); // Remove from active list
        alert(BN_UI_TEXT.ITEM_DELETED);
      } catch (error: any) {
         alert(`লেনদেন সরাতে সমস্যা হয়েছে: ${error.message}`);
      }
    }
  }, [currentUser, transactions]);

  const handleOpenTransactionEditHistoryModal = (transaction: Transaction) => {
    setViewingTransactionEditHistoryFor(transaction); setIsTransactionEditHistoryModalOpen(true);
  };
  const handleCloseTransactionEditHistoryModal = () => setIsTransactionEditHistoryModalOpen(false);

  const resolvePersonForDebt = useCallback(async (personNameValue: string, explicitSelectedPersonId?: string | null): Promise<{personId: string | null, personWasJustCreated: boolean}> => {
    if (!currentUser) return {personId: null, personWasJustCreated: false};
    let finalPersonId: string | undefined | null = explicitSelectedPersonId;
    const trimmedName = personNameValue.trim();
    let personWasJustCreated = false;
    const activePersons = persons; 

    if (!finalPersonId && trimmedName) {
      const existingPerson = activePersons.find(p => p.name.toLowerCase() === trimmedName.toLowerCase() || p.id === trimmedName); 
      if (existingPerson) {
        finalPersonId = existingPerson.id;
      } else {
        const newPerson = await addPerson({ name: trimmedName }); 
        finalPersonId = newPerson.id;
        personWasJustCreated = true;
      }
    }
    return {personId: finalPersonId || null, personWasJustCreated};
  }, [currentUser, persons, addPerson]);


  const addFinancialEntry = useCallback(async (formData: DebtFormSubmitData) => {
    if (!currentUser || !currentUser.email) return;

    const { personId: resolvedPersonId, personWasJustCreated } = await resolvePersonForDebt(formData.personNameValue, formData.explicitSelectedPersonId);

    if (!resolvedPersonId) {
      alert(BN_UI_TEXT.PERSON_NAME_REQUIRED);
      return;
    }
    
    const now = new Date().toISOString();

    if (formData.formPurpose === FormPurpose.RECORD_PERSON_PAYMENT) {
      if (!formData.paymentDate) { 
          alert(BN_UI_TEXT.DEBT_FORM_ALERT_PAYMENT_DATE_REQUIRED); return;
      }
      await addPersonLedgerEntry({
        personId: resolvedPersonId, type: PersonLedgerEntryType.CREDIT, amount: formData.amount,
        description: formData.description, date: formData.paymentDate,
      });
      alert(personWasJustCreated ? BN_UI_TEXT.PERSON_ADDED_IMPLICITLY_FOR_ENTRY.replace("{personName}", formData.personNameValue) : BN_UI_TEXT.LEDGER_ENTRY_FROM_DEBT_FORM_SUCCESS); 
    } else if (formData.formPurpose === FormPurpose.RECORD_USER_PAYMENT_TO_PERSON) {
      if (!formData.paymentDate) {
          alert(BN_UI_TEXT.DEBT_FORM_ALERT_PAYMENT_DATE_REQUIRED); return;
      }
      await addPersonLedgerEntry({
        personId: resolvedPersonId, type: PersonLedgerEntryType.DEBIT, amount: formData.amount,
        description: formData.description, date: formData.paymentDate,
      });
      alert(personWasJustCreated ? BN_UI_TEXT.PERSON_ADDED_IMPLICITLY_FOR_ENTRY.replace("{personName}", formData.personNameValue) : BN_UI_TEXT.LEDGER_ENTRY_USER_PAYMENT_SUCCESS); 
    } else { 
      if (formData.debtType === undefined) { 
          console.error("DebtType is undefined for createPayable/createReceivable formPurpose.");
          alert("An internal error occurred. Debt type missing."); return;
      }
      const id = 'debt-' + Date.now().toString() + Math.random().toString(36).substring(2, 9);
      const newDebtBase: Omit<Debt, 'id' | 'userId' | 'editHistory'> = {
          personId: resolvedPersonId, originalAmount: formData.amount, remainingAmount: formData.amount, 
          description: formData.description, type: formData.debtType, dueDate: formData.dueDate,
          creationDate: now, isSettled: false, lastModified: now,
      };
      const snapshotForVersion: DebtVersion['snapshot'] = { ...newDebtBase, isSettled: false, creationDate: now }; 
      const firstVersion: DebtVersion = { timestamp: now, action: 'created', userId: currentUser.email, snapshot: snapshotForVersion };
      const newDebt: Debt = { ...newDebtBase, id, userId: currentUser.email, editHistory: [firstVersion] };
      
      try {
        await apiService.insertRecord('debts', currentUser.email, newDebt); 
        setDebts(prevDebts => [...prevDebts, newDebt]);
        alert(personWasJustCreated ? BN_UI_TEXT.PERSON_ADDED_IMPLICITLY_DEBT.replace("{personName}", formData.personNameValue) : BN_UI_TEXT.DEBT_ADDED);
      } catch (error: any) {
        alert(`দেনা/পাওনা যোগ করতে সমস্যা হয়েছে: ${error.message}`);
      }
    }
  }, [currentUser, resolvePersonForDebt, addPersonLedgerEntry]);


  const deleteDebt = useCallback(async (id: string) => {
    if (!currentUser || !currentUser.email) return;
    if (window.confirm(BN_UI_TEXT.CONFIRM_DELETE_DEBT_MSG)) {
        try {
            await apiService.deleteRecord('debts', currentUser.email, `id = '${id}'`); 
            setDebts(prevDebts => prevDebts.filter(d => d.id !== id));
            alert(BN_UI_TEXT.DEBT_DELETED);
        } catch (error: any) {
            alert(`দেনা/পাওনা মুছতে সমস্যা হয়েছে: ${error.message}`);
        }
    }
  }, [currentUser]);

  const toggleSettleDebt = useCallback(async (id: string) => {
    if (!currentUser || !currentUser.email) return;
    
    let debtToUpdateFull: Debt | undefined;
    let transactionCreated = false;
    const now = new Date().toISOString();

    const newDebtsState = debts.map(debt => {
        if (debt.id === id) { 
          const person = persons.find(p => p.id === debt.personId);
          const personName = person ? person.name : BN_UI_TEXT.UNKNOWN_PERSON;
          
          let updatedDebtCore = { ...debt, lastModified: now, userId: debt.userId }; 

          if (!debt.isSettled) { 
            if (debt.remainingAmount > 0) {
                 addTransaction({ 
                    description: (debt.type === DebtType.RECEIVABLE ? BN_UI_TEXT.DEBT_SETTLED_INCOME_DESC : BN_UI_TEXT.DEBT_SETTLED_EXPENSE_DESC)
                                .replace("{personName}", personName).replace("{description}", debt.description) + ` (অবশিষ্ট সম্পূর্ণ পরিশোধ)`,
                    amount: debt.remainingAmount, 
                    type: debt.type === DebtType.RECEIVABLE ? TransactionType.INCOME : TransactionType.EXPENSE,
                    date: now, 
                });
                transactionCreated = true;
            }
            updatedDebtCore.remainingAmount = 0;
            updatedDebtCore.isSettled = true;
            updatedDebtCore.settledDate = now;
          } else { 
            updatedDebtCore.isSettled = false;
            updatedDebtCore.settledDate = undefined;
            if(updatedDebtCore.remainingAmount === 0 && debt.isSettled) {
                 updatedDebtCore.remainingAmount = updatedDebtCore.originalAmount;
            }
          }
          
          const { id: debtId, userId: ownerUserId, editHistory, lastModified: lm, ...snapshotDataBase } = updatedDebtCore;
          const newVersionSnapshot: DebtVersion['snapshot'] = {
              ...snapshotDataBase,
          };
          const newVersion: DebtVersion = {
            timestamp: now, action: 'updated', userId: currentUser.email, 
            snapshot: newVersionSnapshot
          };
          debtToUpdateFull = { ...updatedDebtCore, editHistory: [...(debt.editHistory || []), newVersion] };
          return debtToUpdateFull;
        }
        return debt;
      });
    
    if (debtToUpdateFull) {
        setDebts(newDebtsState); 
        try {
            const { id: debtIdToSave, userId: ownerUserIdToSave, ...dataToSet } = debtToUpdateFull; 
            await apiService.updateRecord('debts', currentUser.email, dataToSet, `id = '${debtToUpdateFull.id}'`);
            if (transactionCreated || debtToUpdateFull.isSettled !== debts.find(d=>d.id ===id)?.isSettled) { 
                alert(BN_UI_TEXT.DEBT_UPDATED);
            }
        } catch (error: any) {
            alert(`দেনা/পাওনা আপডেট করতে সমস্যা হয়েছে: ${error.message}`);
            if (!authContextError && !isAuthContextLoading) loadAppData();
        }
    }
  }, [addTransaction, currentUser, persons, debts, loadAppData, authContextError, isAuthContextLoading]);

  const handleOpenEditDebtModal = (debt: Debt) => { setEditingDebt(debt); setIsEditDebtModalOpen(true); };
  const handleCloseEditDebtModal = () => { setEditingDebt(null); setIsEditDebtModalOpen(false); };

  const handleSaveDebt = async (updatedDebtFormData: DebtFormSubmitData, originalDebtId: string) => {
    if (!currentUser || !currentUser.email || !editingDebt) return;

    const {personId: finalPersonId, personWasJustCreated} = await resolvePersonForDebt(updatedDebtFormData.personNameValue, updatedDebtFormData.explicitSelectedPersonId);

    if (!finalPersonId) {
      alert(BN_UI_TEXT.PERSON_NAME_REQUIRED); return;
    }
    if (updatedDebtFormData.formPurpose === FormPurpose.RECORD_PERSON_PAYMENT || 
        updatedDebtFormData.formPurpose === FormPurpose.RECORD_USER_PAYMENT_TO_PERSON || 
        !updatedDebtFormData.debtType) {
        console.error("Invalid form purpose or missing debtType in EditDebtModal save.");
        alert("ত্রুটি: দেনা সম্পাদনার সময় প্রকার পরিবর্তন করা যাবে না।"); return;
    }

    const now = new Date().toISOString();
    let debtToSave: Debt | undefined;

    const newDebts = debts.map(d => {
        if (d.id === originalDebtId) {
          const newOriginalAmount = updatedDebtFormData.amount;
          let newRemainingAmount = d.remainingAmount;
          if (d.originalAmount !== newOriginalAmount) {
            const amountPaid = d.originalAmount - d.remainingAmount;
            newRemainingAmount = Math.max(0, newOriginalAmount - amountPaid);
          }
          const isNowSettled = newRemainingAmount <= 0;
          const updatedDebtCore: Debt = { 
            ...d, 
            personId: finalPersonId, 
            originalAmount: newOriginalAmount,
            remainingAmount: newRemainingAmount, 
            description: updatedDebtFormData.description,
            type: updatedDebtFormData.debtType as DebtType, 
            dueDate: updatedDebtFormData.dueDate,
            isSettled: isNowSettled,
            settledDate: isNowSettled && !d.isSettled ? now : (isNowSettled ? d.settledDate : undefined), 
            lastModified: now,
            userId: d.userId, 
            editHistory: d.editHistory || [] 
          };
          const { id, userId, editHistory, lastModified: lm, ...snapshotDataBase } = updatedDebtCore;
           const newVersionSnapshot: DebtVersion['snapshot'] = { 
             ...snapshotDataBase, 
            };
           const newVersion: DebtVersion = {
            timestamp: now, action: 'updated', userId: currentUser.email!, 
             snapshot: newVersionSnapshot
          };
          debtToSave = { ...updatedDebtCore, editHistory: [...(updatedDebtCore.editHistory || []), newVersion] };
          return debtToSave;
        }
        return d;
      });
    
    if (debtToSave) {
        try {
            const { id: debtId, userId: ownerUserId, ...dataToSet } = debtToSave; 
            await apiService.updateRecord('debts', currentUser.email, dataToSet, `id = '${debtToSave.id}'`);
            setDebts(newDebts);
            alert(personWasJustCreated ? BN_UI_TEXT.PERSON_ADDED_IMPLICITLY_DEBT.replace("{personName}", updatedDebtFormData.personNameValue) : BN_UI_TEXT.DEBT_UPDATED);
            handleCloseEditDebtModal();
        } catch (error: any) {
             alert(`দেনা/পাওনা আপডেট করতে সমস্যা হয়েছে: ${error.message}`);
        }
    }
  };
  
  const handleOpenDebtEditHistoryModal = (debt: Debt) => { setViewingDebtEditHistoryFor(debt); setIsDebtEditHistoryModalOpen(true); };
  const handleCloseDebtEditHistoryModal = () => setIsDebtEditHistoryModalOpen(false);

  const handleOpenManagePersonsModal = () => setIsManagePersonsModalOpen(true);
  const handleCloseManagePersonsModal = () => setIsManagePersonsModalOpen(false);

  const handleOpenPersonFormModal = (person: Person | null = null) => {
    setEditingPerson(person);
    setIsPersonFormModalOpen(true);
  };
  const handleClosePersonFormModal = () => {
    setEditingPerson(null);
    setIsPersonFormModalOpen(false);
  };

  const handleSavePerson = async (data: Omit<Person, 'id'|'userId'|'createdAt'|'lastModified'|'editHistory'>, personId?: string) => {
    if (personId && currentUser && currentUser.email) { 
      await updatePerson(data, personId); 
    } else if (currentUser && currentUser.email) { 
      try {
        await addPerson(data); 
        alert(BN_UI_TEXT.PERSON_ADDED_SUCCESS); 
        setIsPersonFormModalOpen(false); 
      } catch (error) {
        // Error already alerted in addPerson
      }
    }
  };
  
  const handleOpenPersonHistoryModal = (person: Person) => {
    setViewingPersonHistoryFor(person);
    setIsPersonHistoryModalOpen(true);
  };
  const handleClosePersonHistoryModal = () => {
    setViewingPersonHistoryFor(null);
    setIsPersonHistoryModalOpen(false);
  };
  
  const handleOpenSelectPersonModal = (callback: (personId: string) => void) => {
    setSelectPersonCallback(() => callback); 
    setIsSelectPersonModalOpen(true);
  };
  const handleCloseSelectPersonModal = () => setIsSelectPersonModalOpen(false);

  const handleAddNewPersonFromSelect = () => {
    handleCloseSelectPersonModal(); 
    handleOpenPersonFormModal(); 
  };

  const handleOpenPersonDebtsHistoryModal = (person: Person) => {
    setViewingPersonForDebtsHistory(person);
    setIsPersonDebtsHistoryModalOpen(true);
  };
  const handleClosePersonDebtsHistoryModal = () => {
    setViewingPersonForDebtsHistory(null);
    setIsPersonDebtsHistoryModalOpen(false);
  };

  const personSpecificDebtsForHistoryModal = useMemo(() => {
    if (!viewingPersonForDebtsHistory) return [];
    return debts.filter(debt => debt.personId === viewingPersonForDebtsHistory.id); 
  }, [debts, viewingPersonForDebtsHistory]);


  const handleOpenAddLedgerEntryModal = (person: Person) => {
    setSelectedPersonForLedger(person); 
    setIsAddLedgerEntryModalOpen(true);
  };
  const handleCloseAddLedgerEntryModal = () => {
    setIsAddLedgerEntryModalOpen(false);
    setSelectedPersonForLedger(null); 
  };

  const handleDirectAddLedgerEntry = async (data: {personId: string, type: PersonLedgerEntryType, amount: number, description: string, date: string}) => {
    await addPersonLedgerEntry(data); 
  };


  const handleOpenPersonLedgerHistoryModal = (person: Person) => {
    setSelectedPersonForLedger(person);
    setIsPersonLedgerHistoryModalOpen(true);
  };
  const handleClosePersonLedgerHistoryModal = () => {
    setIsPersonLedgerHistoryModalOpen(false);
    if (!isPersonFinancialOverviewModalOpen) { 
        setSelectedPersonForLedger(null);
    }
  };
  
  const personSpecificLedgerEntries = useMemo(() => {
    const targetPerson = selectedPersonForLedger || viewingPersonForOverview;
    if (!targetPerson) return [];
    return personLedgerEntries.filter(entry => entry.personId === targetPerson.id); 
  }, [personLedgerEntries, selectedPersonForLedger, viewingPersonForOverview]);

  const handleOpenPersonFinancialOverviewModal = (person: Person) => {
    setViewingPersonForOverview(person);
    setSelectedPersonForLedger(person); 
    setIsPersonFinancialOverviewModalOpen(true);
  };
  const handleClosePersonFinancialOverviewModal = () => {
    setIsPersonFinancialOverviewModalOpen(false);
    setViewingPersonForOverview(null);
    setSelectedPersonForLedger(null); 
  };

  const personSpecificDebtsForOverview = useMemo(() => {
    if (!viewingPersonForOverview) return [];
    return debts.filter(debt => debt.personId === viewingPersonForOverview.id); 
  }, [debts, viewingPersonForOverview]);
  
  const compositeNetBalanceForOverview = useMemo(() => {
    if (!viewingPersonForOverview) return 0;
    return calculateCompositePersonBalance(viewingPersonForOverview.id);
  }, [viewingPersonForOverview, calculateCompositePersonBalance]);


  const { totalIncome, totalExpense, balance, totalPayable, totalReceivable } = useMemo(() => {
    const activeTransactions = transactions; 
    const activeDebts = debts; 

    const { income, expense } = activeTransactions.reduce(
      (acc, t) => {
        if (t.type === TransactionType.INCOME) acc.income += t.amount;
        else acc.expense += t.amount;
        return acc;
      }, { income: 0, expense: 0 }
    );
    const currentPayable = activeDebts.reduce((acc, d) => (!d.isSettled && d.type === DebtType.PAYABLE && d.remainingAmount > 0 ? acc + d.remainingAmount : acc), 0);
    const currentReceivable = activeDebts.reduce((acc, d) => (!d.isSettled && d.type === DebtType.RECEIVABLE && d.remainingAmount > 0 ? acc + d.remainingAmount : acc), 0);
    return { totalIncome: income, totalExpense: expense, balance: income - expense, totalPayable: currentPayable, totalReceivable: currentReceivable };
  }, [transactions, debts]);

  const handleOpenReceivablePersonsModal = () => setIsReceivablePersonsModalOpen(true);
  const handleCloseReceivablePersonsModal = () => setIsReceivablePersonsModalOpen(false);

  const receivablePersonsData = useMemo((): ReceivablePersonData[] => {
    const personReceivablesMap = new Map<string, { person: Person, totalAmount: number }>();
    const activeDebts = debts; 
    const activePersons = persons; 

    activeDebts.forEach(debt => {
      if (debt.type === DebtType.RECEIVABLE && !debt.isSettled && debt.remainingAmount > 0) {
        const person = activePersons.find(p => p.id === debt.personId);
        if (person) {
          const existing = personReceivablesMap.get(person.id);
          if (existing) existing.totalAmount += debt.remainingAmount;
          else personReceivablesMap.set(person.id, { person, totalAmount: debt.remainingAmount });
        }
      }
    });
    return Array.from(personReceivablesMap.values())
      .map(item => ({ personId: item.person.id, personName: item.person.name, personMobile: item.person.mobileNumber, totalReceivableAmount: item.totalAmount }))
      .sort((a, b) => a.personName.localeCompare(b.personName, 'bn-BD'));
  }, [persons, debts]);

  const handleOpenPayablePersonsModal = () => setIsPayablePersonsModalOpen(true);
  const handleClosePayablePersonsModal = () => setIsPayablePersonsModalOpen(false);

  const payablePersonsData = useMemo((): PayablePersonData[] => {
    const personPayablesMap = new Map<string, { person: Person, totalAmount: number }>();
    const activeDebts = debts; 
    const activePersons = persons; 
    activeDebts.forEach(debt => {
      if (debt.type === DebtType.PAYABLE && !debt.isSettled && debt.remainingAmount > 0) {
        const person = activePersons.find(p => p.id === debt.personId);
        if (person) {
          const existing = personPayablesMap.get(person.id);
          if (existing) existing.totalAmount += debt.remainingAmount;
          else personPayablesMap.set(person.id, { person, totalAmount: debt.remainingAmount });
        }
      }
    });
    return Array.from(personPayablesMap.values())
      .map(item => ({ personId: item.person.id, personName: item.person.name, personMobile: item.person.mobileNumber, totalPayableAmount: item.totalAmount }))
      .sort((a, b) => a.personName.localeCompare(b.personName, 'bn-BD'));
  }, [persons, debts]);


  const handleAuthFormClose = () => setShowAuthForm(null);

  const handleResetApplicationData = async () => {
    if (window.confirm(BN_UI_TEXT.CONFIRM_RESET_APP_DATA_MSG)) {
      if (currentUser && currentUser.email) {
        setIsLoadingData(true);
        setAppError(null);
        try {
          const tableNames = ['transactions', 'persons', 'debts', 'person_ledger_entries', 'user_transaction_suggestions', 'budgets', 'budgetCategories'];
          for (const baseName of tableNames) {
            await apiService.deleteRecord(baseName, currentUser.email, "1"); 
          }
          alert("ব্যবহারকারীর ডেটা রিসেট সম্পন্ন হয়েছে।");
        } catch (error: any) {
           setAppError(`ডেটা রিসেট করতে সমস্যা হয়েছে: ${error.message}`);
           setIsLoadingData(false);
           return; 
        } finally {
            setIsLoadingData(false);
        }
      }
      authLogout();       
      alert(BN_UI_TEXT.APP_DATA_RESET_SUCCESS);
      window.location.reload();
    }
  };

  // --- Budgeting Feature Functions ---
  const handleOpenBudgetSetupModal = () => setIsBudgetSetupModalOpen(true);
  const handleCloseBudgetSetupModal = () => setIsBudgetSetupModalOpen(false);

  const addBudgetCategory = async (name: string, associatedSuggestions: string[]) => {
    if (!currentUser || !currentUser.email) return;
    const trimmedName = name.trim();
    if (!trimmedName) {
      alert(BN_UI_TEXT.BUDGET_CATEGORY_NAME_REQUIRED);
      return;
    }
    if (budgetCategories.some(cat => cat.name.toLowerCase() === trimmedName.toLowerCase())) {
      alert(BN_UI_TEXT.BUDGET_CATEGORY_EXISTS_ERROR);
      return;
    }
    const now = new Date().toISOString();
    const newCategory: BudgetCategory = {
      id: 'bcat-' + Date.now().toString() + Math.random().toString(36).substring(2, 9),
      userId: currentUser.email,
      name: trimmedName,
      createdAt: now,
      lastModified: now,
      associatedSuggestions: associatedSuggestions,
    };
    try {
      await apiService.insertRecord('budgetCategories', currentUser.email, newCategory);
      setBudgetCategories(prev => [...prev, newCategory].sort((a, b) => a.name.localeCompare(b.name, 'bn-BD')));
      alert(BN_UI_TEXT.BUDGET_CATEGORY_ADDED_SUCCESS);
    } catch (error: any) {
      alert(`বাজেট ক্যাটেগরি যোগ করতে সমস্যা হয়েছে: ${error.message}`);
    }
  };

  const updateBudgetCategory = async (id: string, newName: string, associatedSuggestions: string[]) => {
    if (!currentUser || !currentUser.email) return;
    const trimmedName = newName.trim();
    if (!trimmedName) {
      alert(BN_UI_TEXT.BUDGET_CATEGORY_NAME_REQUIRED);
      return;
    }
    const existingCategory = budgetCategories.find(cat => cat.id === id);
    if (!existingCategory) return;

    if (budgetCategories.some(cat => cat.id !== id && cat.name.toLowerCase() === trimmedName.toLowerCase())) {
      alert(BN_UI_TEXT.BUDGET_CATEGORY_EXISTS_ERROR);
      return;
    }
    const updatedCategoryData = { 
      name: trimmedName, 
      lastModified: new Date().toISOString(),
      associatedSuggestions: associatedSuggestions,
    };
    try {
      await apiService.updateRecord('budgetCategories', currentUser.email, updatedCategoryData, `id = '${id}'`);
      setBudgetCategories(prev => prev.map(cat => cat.id === id ? { ...cat, ...updatedCategoryData } : cat).sort((a, b) => a.name.localeCompare(b.name, 'bn-BD')));
      alert(BN_UI_TEXT.BUDGET_CATEGORY_UPDATED_SUCCESS);
    } catch (error: any) {
      alert(`বাজেট ক্যাটেগরি আপডেট করতে সমস্যা হয়েছে: ${error.message}`);
    }
  };
  
  const deleteBudgetCategory = async (id: string) => {
    if (!currentUser || !currentUser.email) return;
    if (budgets.some(budget => budget.categoryId === id)) {
      alert(BN_UI_TEXT.BUDGET_CATEGORY_HAS_BUDGETS_ERROR);
      return;
    }
    if (window.confirm(BN_UI_TEXT.CONFIRM_DELETE_BUDGET_CATEGORY_MSG)) {
      try {
        await apiService.deleteRecord('budgetCategories', currentUser.email, `id = '${id}'`);
        setBudgetCategories(prev => prev.filter(cat => cat.id !== id));
        // If cascade delete is not handled by DB, ensure associated budgets are also deleted
        const budgetsToDelete = budgets.filter(b => b.categoryId === id);
        for (const budget of budgetsToDelete) {
          await apiService.deleteRecord('budgets', currentUser.email, `id = '${budget.id}'`);
        }
        setBudgets(prev => prev.filter(b => b.categoryId !== id));
        alert(BN_UI_TEXT.BUDGET_CATEGORY_DELETED_SUCCESS);
      } catch (error: any) {
        alert(`বাজেট ক্যাটেগরি মুছতে সমস্যা হয়েছে: ${error.message}`);
      }
    }
  };

  const addBudget = async (categoryId: string, amount: number, period: BudgetPeriod, startDateString: string) => {
    if (!currentUser || !currentUser.email) return;
    if (!categoryId) {
        alert(BN_UI_TEXT.BUDGET_CATEGORY_NOT_SELECTED); return;
    }
    if (amount <= 0 || isNaN(amount)) {
        alert(BN_UI_TEXT.BUDGET_INVALID_AMOUNT); return;
    }
    if (!startDateString) {
        alert(BN_UI_TEXT.BUDGET_INVALID_START_DATE); return;
    }

    const startDate = new Date(startDateString);
    startDate.setDate(1); 
    startDate.setHours(0, 0, 0, 0);

    const endDate = new Date(startDate);
    endDate.setMonth(startDate.getMonth() + 1);
    endDate.setDate(0); 
    endDate.setHours(23, 59, 59, 999);

    const existingBudget = budgets.find(b => 
        b.categoryId === categoryId && 
        b.period === period && 
        new Date(b.startDate).getFullYear() === startDate.getFullYear() &&
        new Date(b.startDate).getMonth() === startDate.getMonth()
    );

    if (existingBudget) {
        alert(BN_UI_TEXT.BUDGET_EXISTS_FOR_CATEGORY_MONTH_ERROR);
        return;
    }

    const now = new Date().toISOString();
    const newBudget: Budget = {
      id: 'budget-' + Date.now().toString() + Math.random().toString(36).substring(2, 9),
      userId: currentUser.email,
      categoryId,
      amount,
      period,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      createdAt: now,
      lastModified: now,
    };

    try {
      await apiService.insertRecord('budgets', currentUser.email, newBudget);
      setBudgets(prev => [...prev, newBudget].sort((a,b) => new Date(b.startDate).getTime() - new Date(a.startDate).getTime() || a.categoryId.localeCompare(b.categoryId)));
      alert(BN_UI_TEXT.BUDGET_ADDED_SUCCESS);
    } catch (error: any) {
      alert(`বাজেট যোগ করতে সমস্যা হয়েছে: ${error.message}`);
    }
  };

  const updateBudget = async (id: string, newAmount: number) => {
    if (!currentUser || !currentUser.email) return;
     if (newAmount <= 0 || isNaN(newAmount)) {
        alert(BN_UI_TEXT.BUDGET_INVALID_AMOUNT); return;
    }
    const budgetToUpdate = budgets.find(b => b.id === id);
    if (!budgetToUpdate) return;

    const updatedBudgetData = { 
      amount: newAmount, 
      lastModified: new Date().toISOString()
    };

    try {
      await apiService.updateRecord('budgets', currentUser.email, updatedBudgetData, `id = '${id}'`);
      setBudgets(prev => prev.map(b => b.id === id ? { ...b, ...updatedBudgetData } : b));
      alert(BN_UI_TEXT.BUDGET_UPDATED_SUCCESS);
    } catch (error: any) {
      alert(`বাজেট আপডেট করতে সমস্যা হয়েছে: ${error.message}`);
    }
  };

  const deleteBudget = async (id: string) => {
    if (!currentUser || !currentUser.email) return;
    if (window.confirm(BN_UI_TEXT.CONFIRM_DELETE_BUDGET_MSG)) {
      try {
        await apiService.deleteRecord('budgets', currentUser.email, `id = '${id}'`);
        setBudgets(prev => prev.filter(b => b.id !== id));
        alert(BN_UI_TEXT.BUDGET_DELETED_SUCCESS);
      } catch (error: any) {
        alert(`বাজেট মুছতে সমস্যা হয়েছে: ${error.message}`);
      }
    }
  };

  const calculateBudgetUsage = useCallback((budget: Budget, currentTransactions: Transaction[]) => {
    // Placeholder: Actual implementation requires transactions to be categorized.
    // For now, it returns 0 spent.
    // TODO: Enhance Transaction type to include categoryId and filter transactions by category and date range.
    const spent = 0; 
    const remaining = budget.amount - spent;
    const percentageUsed = budget.amount > 0 ? (spent / budget.amount) * 100 : 0;
    return { spent, remaining, percentageUsed };
  }, []);


  // --- End of Budgeting Functions ---
  
  if (showAuthForm) {
    return <AuthForm mode={showAuthForm} onClose={handleAuthFormClose} onSwitchMode={(mode) => setShowAuthForm(mode)} />;
  }

  const activeTransactions = transactions; 
  const activePersons = persons; 
  const activeDebts = debts; 


  return (
    <div className="min-h-screen bg-slate-100 text-slate-800">
      <Header 
        onLoginClick={() => setShowAuthForm('login')} 
        onSignupClick={() => setShowAuthForm('signup')}
        onAddTransactionClick={() => setIsAddTransactionModalOpen(true)}
        onAddDebtClick={() => setIsDebtManagementModalOpen(true)}
        onViewTransactionsClick={() => setIsViewTransactionsModalOpen(true)}
        onManagePersonsClick={handleOpenManagePersonsModal}
        onViewReportClick={() => setIsReportModalOpen(true)} 
        onBudgetClick={handleOpenBudgetSetupModal} 
      />
      <main className="container mx-auto max-w-4xl p-3 sm:p-4">
        {(isAuthContextLoading || isLoadingData) && !appError && ( 
            <div className="fixed inset-0 bg-white bg-opacity-75 flex items-center justify-center z-[200]">
                <div className="text-center">
                    <div role="status" className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-teal-500 border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]">
                        <span className="!absolute !-m-px !h-px !w-px !overflow-hidden !whitespace-nowrap !border-0 !p-0 ![clip:rect(0,0,0,0)]">লোড হচ্ছে...</span>
                    </div>
                    <p className="mt-4 text-lg text-teal-600 font-medium">{isAuthContextLoading ? "প্রমাণীকরণ প্রক্রিয়া চলছে..." : BN_UI_TEXT.LOADING}</p>
                </div>
            </div>
        )}
        {appError && ( 
            <div className="my-4 p-4 bg-red-100 border-l-4 border-red-500 text-red-700 rounded-md shadow-md">
                <p className="font-semibold">একটি ত্রুটি ঘটেছে:</p>
                <p>{appError}</p>
                <button onClick={() => setAppError(null)} className="mt-2 text-sm text-red-600 hover:underline">বন্ধ করুন</button>
            </div>
        )}

        {!currentUser && !isAuthContextLoading && !authContextError && ( 
          <div className="my-8 p-6 bg-white rounded-xl shadow-lg text-center">
            <h2 className="text-xl font-semibold text-slate-700 mb-4">{BN_UI_TEXT.WELCOME_TO_APP}</h2>
            <p className="text-slate-600 mb-6">{BN_UI_TEXT.PLEASE_LOGIN_SIGNUP_TO_PROCEED}</p>
            <div className="mb-6 flex justify-center space-x-4">
                <button onClick={() => setShowAuthForm('login')} className="bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-6 rounded-lg shadow-md">{BN_UI_TEXT.LOGIN}</button>
                <button onClick={() => setShowAuthForm('signup')} className="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-6 rounded-lg shadow-md">{BN_UI_TEXT.SIGNUP}</button>
            </div>
            <div className="mt-8 p-4 bg-yellow-50 border border-yellow-300 rounded-md text-sm text-yellow-700">
              <h3 className="font-semibold">{BN_UI_TEXT.MOCKED_AUTH_WARNING_TITLE}</h3><p>{BN_UI_TEXT.MOCKED_AUTH_WARNING_DESC}</p>
               <p className="mt-2"><strong>নোট:</strong> অ্যাপটি এখন শেয়ার্ড টেবিল ব্যবহার করার জন্য আপডেট করা হয়েছে, যার জন্য ব্যাকএন্ডে (PHP) পরিবর্তন প্রয়োজন। পুরাতন ইউজার-স্পেসিফিক টেবিল নামের পরিবর্তে এখন `user_id` দ্বারা ডেটা পৃথক করা হবে।</p>
            </div>
          </div>
        )}
        
        {currentUser && !authContextError && !isAuthContextLoading && ( 
          <>
            <Summary 
              totalIncome={totalIncome} 
              totalExpense={totalExpense} 
              balance={balance} 
              totalPayable={totalPayable} 
              totalReceivable={totalReceivable} 
              onOpenReceivablePersonsModal={handleOpenReceivablePersonsModal}
              onOpenPayablePersonsModal={handleOpenPayablePersonsModal}
            />
            <AITipCard balance={balance} />

            <Modal isOpen={isAddTransactionModalOpen} onClose={() => setIsAddTransactionModalOpen(false)} title={BN_UI_TEXT.MODAL_TITLE_ADD_TRANSACTION} size="2xl">
              <div className="space-y-6">
                <TransactionForm 
                  onAddTransaction={(data) => addTransaction(data)} 
                  showTitle={false} 
                  allSuggestions={allTransactionSuggestions}
                  onOpenManageSuggestions={handleOpenManageSuggestionsModal}
                />
                <hr className="my-4 border-slate-200" /> 
                <TransactionList transactions={activeTransactions} onDeleteTransaction={deleteTransaction} onEditTransaction={handleOpenEditModal} onViewHistory={handleOpenTransactionEditHistoryModal} showTitle={false} />
              </div>
            </Modal>

            <Modal isOpen={isDebtManagementModalOpen} onClose={() => setIsDebtManagementModalOpen(false)} title={BN_UI_TEXT.MODAL_TITLE_ADD_DEBT} size="2xl">
              <div className="space-y-6">
                <DebtForm 
                  onAddDebt={addFinancialEntry} 
                  showTitle={false} 
                  persons={activePersons} 
                  debts={activeDebts} 
                  onOpenSelectPersonModal={handleOpenSelectPersonModal}
                  getCompositePersonBalance={calculateCompositePersonBalance}
                />
                <hr className="my-4 border-slate-200" />
                <DebtList 
                  debts={activeDebts} 
                  persons={activePersons} 
                  onDeleteDebt={deleteDebt} 
                  onToggleSettle={toggleSettleDebt} 
                  onEditDebt={handleOpenEditDebtModal} 
                  onViewHistory={handleOpenDebtEditHistoryModal} 
                  onViewPersonFinancialOverview={handleOpenPersonFinancialOverviewModal}
                />
              </div>
            </Modal>

            <Modal isOpen={isViewTransactionsModalOpen} onClose={() => setIsViewTransactionsModalOpen(false)} title={BN_UI_TEXT.MODAL_TITLE_TRANSACTION_HISTORY} size="3xl">
              <TransactionList transactions={activeTransactions} onDeleteTransaction={deleteTransaction} onEditTransaction={handleOpenEditModal} onViewHistory={handleOpenTransactionEditHistoryModal} showTitle={false} />
            </Modal>
            
            {isEditModalOpen && editingTransaction && (
              <EditTransactionModal 
                isOpen={isEditModalOpen} 
                onClose={handleCloseEditModal} 
                transaction={editingTransaction} 
                onSave={handleSaveTransaction} 
                allSuggestions={allTransactionSuggestions}
                onOpenManageSuggestions={handleOpenManageSuggestionsModal}
              />
            )}
            {isEditDebtModalOpen && editingDebt && (
              <EditDebtModal isOpen={isEditDebtModalOpen} onClose={handleCloseEditDebtModal} debt={editingDebt} onSave={handleSaveDebt} persons={persons} onOpenSelectPersonModal={handleOpenSelectPersonModal}/>
            )}
            {isTransactionEditHistoryModalOpen && viewingTransactionEditHistoryFor && (
              <TransactionHistoryModal isOpen={isTransactionEditHistoryModalOpen} onClose={handleCloseTransactionEditHistoryModal} transaction={viewingTransactionEditHistoryFor} />
            )}
            {isDebtEditHistoryModalOpen && viewingDebtEditHistoryFor && (
              <DebtHistoryModal isOpen={isDebtEditHistoryModalOpen} onClose={handleCloseDebtEditHistoryModal} debt={viewingDebtEditHistoryFor} persons={persons} />
            )}

            <Modal isOpen={isManagePersonsModalOpen} onClose={handleCloseManagePersonsModal} title={BN_UI_TEXT.MANAGE_PERSONS_MODAL_TITLE} size="2xl">
              <PersonList 
                persons={activePersons} 
                onEditPerson={handleOpenPersonFormModal} 
                onDeletePerson={deletePerson} 
                onViewPersonHistory={handleOpenPersonHistoryModal}
                onAddNewPerson={() => handleOpenPersonFormModal(null)}
                onViewPersonDebtsHistory={handleOpenPersonDebtsHistoryModal}
                onViewPersonLedger={handleOpenPersonFinancialOverviewModal}
                getPersonNetLedgerBalance={(personId) => calculateCompositePersonBalance(personId)} 
              />
            </Modal>
            <Modal isOpen={isPersonFormModalOpen} onClose={handleClosePersonFormModal} title={editingPerson ? BN_UI_TEXT.EDIT_PERSON_MODAL_TITLE : BN_UI_TEXT.ADD_PERSON_MODAL_TITLE} size="lg">
              <PersonForm 
                onSave={handleSavePerson} 
                initialData={editingPerson}
                onCancel={handleClosePersonFormModal}
                allPersons={persons} 
              />
            </Modal>
            {isPersonHistoryModalOpen && viewingPersonHistoryFor && (
              <PersonHistoryModal 
                isOpen={isPersonHistoryModalOpen} 
                onClose={handleClosePersonHistoryModal} 
                person={viewingPersonHistoryFor}
              />
            )}
            {isSelectPersonModalOpen && (
              <SelectPersonModal 
                isOpen={isSelectPersonModalOpen}
                onClose={handleCloseSelectPersonModal}
                persons={activePersons}
                onSelectPerson={(personId) => {
                  if (selectPersonCallback) selectPersonCallback(personId); 
                  handleCloseSelectPersonModal();
                }}
                onAddNewPerson={handleAddNewPersonFromSelect}
              />
            )}
            {isPersonDebtsHistoryModalOpen && viewingPersonForDebtsHistory && (
              <PersonDebtsHistoryModal
                isOpen={isPersonDebtsHistoryModalOpen}
                onClose={handleClosePersonDebtsHistoryModal}
                person={viewingPersonForDebtsHistory}
                personDebts={personSpecificDebtsForHistoryModal}
                allPersons={persons} 
                onDeleteDebt={deleteDebt}
                onToggleSettle={toggleSettleDebt}
                onEditDebt={handleOpenEditDebtModal}
                onViewDebtHistory={handleOpenDebtEditHistoryModal}
              />
            )}
             {isAddLedgerEntryModalOpen && selectedPersonForLedger && (
              <AddPersonLedgerEntryModal
                isOpen={isAddLedgerEntryModalOpen}
                onClose={handleCloseAddLedgerEntryModal}
                person={selectedPersonForLedger}
                onAddEntry={handleDirectAddLedgerEntry} 
              />
            )}
            {isPersonLedgerHistoryModalOpen && selectedPersonForLedger && (
              <PersonLedgerHistoryModal
                isOpen={isPersonLedgerHistoryModalOpen}
                onClose={handleClosePersonLedgerHistoryModal}
                person={selectedPersonForLedger}
                ledgerEntries={personSpecificLedgerEntries} 
                currentNetBalance={getLedgerOnlyNetBalance(selectedPersonForLedger.id)} 
                onAddEntryClick={handleOpenAddLedgerEntryModal}
                onDeleteEntry={deletePersonLedgerEntry}
              />
            )}
            {isPersonFinancialOverviewModalOpen && viewingPersonForOverview && (
                <PersonFinancialOverviewModal
                    isOpen={isPersonFinancialOverviewModalOpen}
                    onClose={handleClosePersonFinancialOverviewModal}
                    person={viewingPersonForOverview}
                    personDebts={debts.filter(d => d.personId === viewingPersonForOverview.id)} 
                    personLedgerEntries={personLedgerEntries.filter(ple => ple.personId === viewingPersonForOverview.id)} 
                    currentNetLedgerBalance={compositeNetBalanceForOverview} 
                    allPersons={persons} 
                    onDeleteDebt={deleteDebt}
                    onToggleSettle={toggleSettleDebt}
                    onEditDebt={handleOpenEditDebtModal}
                    onViewDebtHistory={handleOpenDebtEditHistoryModal}
                    onAddLedgerEntryClick={handleOpenAddLedgerEntryModal} 
                    onDeleteLedgerEntry={deletePersonLedgerEntry}
                />
            )}
            {isReceivablePersonsModalOpen && (
              <ReceivablePersonsModal
                isOpen={isReceivablePersonsModalOpen}
                onClose={handleCloseReceivablePersonsModal}
                receivablePersons={receivablePersonsData}
                onViewPersonDetails={handleOpenPersonFinancialOverviewModal} 
                persons={persons} 
              />
            )}
            {isPayablePersonsModalOpen && (
              <PayablePersonsModal
                isOpen={isPayablePersonsModalOpen}
                onClose={handleClosePayablePersonsModal}
                payablePersons={payablePersonsData}
                onViewPersonDetails={handleOpenPersonFinancialOverviewModal}
                persons={persons}
              />
            )}
             {isReportModalOpen && (
              <ReportModal
                isOpen={isReportModalOpen}
                onClose={() => setIsReportModalOpen(false)}
                transactions={transactions} 
                onDeleteTransaction={deleteTransaction}
                onEditTransaction={handleOpenEditModal}
                onViewHistory={handleOpenTransactionEditHistoryModal}
              />
            )}
             {isManageSuggestionsModalOpen && (
              <ManageSuggestionsModal
                isOpen={isManageSuggestionsModalOpen}
                onClose={handleCloseManageSuggestionsModal}
                userSuggestions={userCustomSuggestions}
                predefinedSuggestions={TRANSACTION_DESCRIPTION_SUGGESTIONS_BN}
                onAddSuggestion={addUserCustomSuggestion}
                onEditSuggestion={editUserCustomSuggestion}
                onDeleteSuggestion={deleteUserCustomSuggestion}
              />
            )}
            {isBudgetSetupModalOpen && currentUser && (
              <BudgetSetupModal
                isOpen={isBudgetSetupModalOpen}
                onClose={handleCloseBudgetSetupModal}
                categories={budgetCategories}
                budgets={budgets}
                transactions={transactions} 
                allTransactionSuggestions={allTransactionSuggestions}
                userCustomSuggestions={userCustomSuggestions}
                onAddCategory={addBudgetCategory}
                onUpdateCategory={updateBudgetCategory}
                onDeleteCategory={deleteBudgetCategory}
                onAddBudget={addBudget}
                onUpdateBudget={updateBudget}
                onDeleteBudget={deleteBudget}
                calculateBudgetUsage={calculateBudgetUsage}
              />
            )}
          </>
        )}
      </main>
      <footer className="text-center py-6 text-slate-500 text-sm bg-slate-200 mt-8">
         {currentUser && ( <div className="my-4 p-3 bg-slate-100 rounded-md max-w-md mx-auto text-xs shadow"><p>আপনি বর্তমানে <strong>{currentUser.name || currentUser.email}</strong> হিসেবে লগইন আছেন।</p></div> )}
        <p>&copy; {new Date().getFullYear()} {BN_UI_TEXT.APP_TITLE}.</p>
        <p>Gemini API দ্বারা চালিত আর্থিক পরামর্শ।</p>
         <div className="mt-3 p-2 bg-orange-100 border border-orange-300 rounded-md text-xs text-orange-700 max-w-xl mx-auto shadow">
            <p><strong>গুরুত্বপূর্ণ:</strong> এই অ্যাপ্লিকেশনের লগইন/সাইনআপ ব্যবস্থাটি সিমুলেটেড। ব্যাকএন্ড ইন্টিগ্রেশন সম্পন্ন হলেও, প্রদত্ত API টি একটি সাধারণ ডাটাবেস ইন্টারফেস এবং এতে ব্যবহারকারী-ভিত্তিক ডেটা সুরক্ষা বা প্রমাণীকরণের সম্পূর্ণ ব্যবস্থা নেই। একটি সম্পূর্ণ সুরক্ষিত সিস্টেমের জন্য ব্যাকএন্ডে আরও শক্তিশালী প্রমাণীকরণ এবং অনুমোদনের প্রয়োজন।</p>
            <p className="mt-1"><strong>আপডেট:</strong> অ্যাপটি এখন শেয়ার্ড টেবিলের সাথে কাজ করার জন্য পরিবর্তিত হয়েছে, যেখানে প্রতিটি রেকর্ডের সাথে `user_id` যুক্ত থাকবে। আপনার PHP ব্যাকএন্ড এই পরিবর্তন সমর্থন করার জন্য আপডেট করা আবশ্যক।</p>
        </div>
        <div className="mt-6">
          <button onClick={handleResetApplicationData} className="bg-orange-500 hover:bg-orange-600 text-white text-sm font-semibold py-2 px-4 rounded-lg shadow-md" aria-label={BN_UI_TEXT.RESET_APP_DATA_BTN}>{BN_UI_TEXT.RESET_APP_DATA_BTN}</button>
        </div>
      </footer>
    </div>
  );
};

const App: React.FC = () => ( <AuthProvider> <AppContent /> </AuthProvider> );
export default App;