
import bcrypt from 'bcryptjs';
import { User } from '../types';
import { BN_UI_TEXT, APP_TITLE_FOR_EMAIL } from '../constants'; 
import * as apiService from '../apiService'; 

const SALT_ROUNDS = 10; 

export const signupUser = async (name: string, email: string, password: string): Promise<User> => {
  const normalizedEmail = email.toLowerCase();
  try {
    const existingUsers = await apiService.fetchRecords<User>('users', normalizedEmail, `email = '${normalizedEmail.replace(/'/g, "''")}'`);
    if (existingUsers && existingUsers.length > 0) {
      throw new Error(BN_UI_TEXT.AUTH_ERROR_EMAIL_EXISTS);
    }

    const hashedPasswordValue = await bcrypt.hash(password, SALT_ROUNDS);
    const userId = 'user_' + Date.now().toString() + Math.random().toString(36).substring(2, 9);

    const newUser: User = {
      id: userId,
      name,
      email: normalizedEmail,
      hashed_password: hashedPasswordValue,
    };

    const response = await apiService.insertRecord('users', normalizedEmail, newUser);
    
    if (response.success) {
      return { id: newUser.id, name: newUser.name, email: newUser.email };
    } else {
      if (typeof response.error === 'string' && 
          (
            (response.error.includes("Duplicate entry") && response.error.toLowerCase().includes("for key") && response.error.toLowerCase().includes("email")) ||
            response.error.includes("1062") 
          )
      ) {
        throw new Error(BN_UI_TEXT.AUTH_ERROR_EMAIL_EXISTS);
      }
      throw new Error(response.error || "User registration failed via tableInsert.");
    }

  } catch (error: any) {
    console.error("Signup error in authService:", error);
    if (error.message === BN_UI_TEXT.AUTH_ERROR_EMAIL_EXISTS) {
        throw error;
    }
    if (typeof error.message === 'string' && 
        (
          (error.message.includes("Duplicate entry") && error.message.toLowerCase().includes("for key") && error.message.toLowerCase().includes("email")) ||
          error.message.includes("1062") 
        )
    ) {
        throw new Error(BN_UI_TEXT.AUTH_ERROR_EMAIL_EXISTS);
    }
    throw new Error(error.message || BN_UI_TEXT.AUTH_ERROR_GENERAL);
  }
};

export const loginUser = async (email: string, password: string): Promise<User> => {
  const normalizedEmail = email.toLowerCase();
  try {
    const users = await apiService.fetchRecords<User>('users', normalizedEmail, `email = '${normalizedEmail.replace(/'/g, "''")}'`);

    if (!users || users.length === 0) {
      throw new Error(BN_UI_TEXT.AUTH_ERROR_INVALID_CREDENTIALS);
    }

    const user = users[0];
    if (!user.hashed_password) { 
        console.error("User found but has no hashed password stored:", user);
        throw new Error(BN_UI_TEXT.AUTH_ERROR_GENERAL + " (User data incomplete)");
    }

    const isMatch = await bcrypt.compare(password, user.hashed_password); 
    if (isMatch) {
      const { hashed_password, ...userWithoutPassword } = user; 
      return userWithoutPassword;
    } else {
      throw new Error(BN_UI_TEXT.AUTH_ERROR_INVALID_CREDENTIALS);
    }
  } catch (error: any) {
    console.error("Login error in authService:", error);
    // Ensure the specific error message is thrown if it's already one of ours
    if (error.message === BN_UI_TEXT.AUTH_ERROR_INVALID_CREDENTIALS || error.message.includes(BN_UI_TEXT.AUTH_ERROR_GENERAL)) {
        throw error;
    }
    throw new Error(BN_UI_TEXT.AUTH_ERROR_INVALID_CREDENTIALS); // Default to invalid credentials
  }
};

export const requestPasswordResetCode = async (email: string): Promise<void> => {
  const normalizedEmail = email.toLowerCase();
  try {
    const response = await apiService.requestPasswordReset(normalizedEmail); // New apiService function
    if (!response.success) {
      // Even if backend says user not found, we give a generic success message for security.
      // But if there's another backend error, throw it.
      if(response.error && !response.error.toLowerCase().includes("user not found")) { // Example check
          throw new Error(response.error || BN_UI_TEXT.RESET_CODE_SENT_FAIL);
      }
    }
    // Frontend always assumes "attempted to send" for security (don't reveal if email exists)
    // Actual email sending is handled by the backend.
    // The alert in AuthContext is sufficient.
  } catch (error: any) {
    console.error("Request password reset code error in authService:", error);
    // Don't reveal if email exists or not, throw generic error.
    throw new Error(BN_UI_TEXT.RESET_CODE_SENT_FAIL);
  }
};

export const resetPasswordWithCode = async (email: string, code: string, newPassword: string): Promise<void> => {
  const normalizedEmail = email.toLowerCase();
  try {
    const response = await apiService.resetPasswordWithCode(normalizedEmail, code, newPassword); // New apiService function
    if (!response.success) {
      const specificError = response.error?.toLowerCase().includes("invalid") || response.error?.toLowerCase().includes("expired")
        ? BN_UI_TEXT.INVALID_RESET_CODE
        : (response.error || BN_UI_TEXT.AUTH_ERROR_GENERAL);
      throw new Error(specificError);
    }
    // Success handled in AuthContext
  } catch (error: any) {
    console.error("Reset password with code error in authService:", error);
    if (error.message === BN_UI_TEXT.INVALID_RESET_CODE || error.message === BN_UI_TEXT.AUTH_ERROR_GENERAL){
        throw error;
    }
    throw new Error(BN_UI_TEXT.AUTH_ERROR_GENERAL);
  }
};
