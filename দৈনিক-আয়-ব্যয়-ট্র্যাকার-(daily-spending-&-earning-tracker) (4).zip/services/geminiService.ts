
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_MODEL_TEXT, GEMINI_PROMPT_LANG } from '../constants';

const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;

if (API_KEY) {
  try {
    ai = new GoogleGenAI({ apiKey: API_KEY });
  } catch (error) {
    console.error("Failed to initialize GoogleGenAI:", error);
    ai = null; 
  }
} else {
  console.warn("API_KEY environment variable is not set. Gemini AI features will be unavailable.");
}

export const isGeminiAvailable = (): boolean => !!ai;

export const getFinancialTip = async (balance: number, language: string = GEMINI_PROMPT_LANG): Promise<string> => {
  if (!ai) {
    throw new Error("Gemini AI service is not initialized. API_KEY might be missing.");
  }

  const model = GEMINI_MODEL_TEXT;
  
  const prompt = `Based on a current account balance of ${balance} BDT, provide one concise and practical financial tip in simple ${language}. The tip should be encouraging and easy to understand. If the balance is low, suggest a small saving habit. If the balance is good, suggest a wise investment or saving goal. Respond in ${language} only. Keep it under 150 characters.`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: model,
        contents: prompt,
    });
    
    const text = response.text;
    if (!text) {
        throw new Error("No text content in Gemini response.");
    }
    return text.trim();
  } catch (error) {
    console.error("Error fetching financial tip from Gemini:", error);
    if (error instanceof Error) {
        throw new Error(`Gemini API error: ${error.message}`);
    }
    throw new Error("An unknown error occurred while fetching financial tip.");
  }
};
