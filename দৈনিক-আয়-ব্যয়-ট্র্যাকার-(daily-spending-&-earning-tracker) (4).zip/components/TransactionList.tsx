


import React from 'react';
import { Transaction } from '../types';
import { BN_UI_TEXT } from '../constants';
import TransactionItem from './TransactionItem';

interface TransactionListProps {
  transactions: Transaction[];
  onDeleteTransaction: (id: string) => void;
  onEditTransaction: (transaction: Transaction) => void; 
  onViewHistory: (transaction: Transaction) => void;
  showTitle?: boolean; 
}

const TransactionList: React.FC<TransactionListProps> = ({ 
  transactions, 
  onDeleteTransaction, 
  onEditTransaction, 
  onViewHistory,
  showTitle = true 
}) => {

  if (transactions.length === 0) {
    return (
      <section aria-labelledby={showTitle ? "transaction-history-heading" : undefined} className={`${showTitle ? 'my-8 p-6 bg-white rounded-xl shadow-lg text-center' : 'text-center py-4'}`}>
         {showTitle && (
            <h2 id="transaction-history-heading" className="text-2xl font-semibold text-slate-700 mb-6">
            {BN_UI_TEXT.TRANSACTION_HISTORY}
            </h2>
         )}
        <p className="text-slate-500">{BN_UI_TEXT.NO_TRANSACTIONS}</p>
      </section>
    );
  }

  const sortedTransactions = [...transactions].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <section aria-labelledby={showTitle ? "transaction-history-heading" : undefined} className={`${showTitle ? 'my-8 p-4 md:p-6 bg-white rounded-xl shadow-lg' : ''}`}>
      {showTitle && (
        <h2 id="transaction-history-heading" className="text-2xl font-semibold text-slate-700 mb-6 text-center">
          {BN_UI_TEXT.TRANSACTION_HISTORY}
        </h2>
      )}
      <ul className="space-y-4">
        {sortedTransactions.map((transaction) => (
          <TransactionItem
            key={transaction.id}
            transaction={transaction}
            onDeleteTransaction={onDeleteTransaction}
            onEditTransaction={onEditTransaction}
            onViewHistory={onViewHistory}
          />
        ))}
      </ul>
    </section>
  );
};

export default TransactionList;