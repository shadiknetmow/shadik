

import React, { useState, useEffect, FormEvent } from 'react';
import { Person } from '../types';
import { BN_UI_TEXT } from '../constants';

interface PersonFormProps {
  onSave: (personData: Omit<Person, 'id' | 'userId' | 'createdAt' | 'lastModified' | 'editHistory'>, existingPersonId?: string) => void;
  initialData?: Person | null; // For editing
  onCancel: () => void;
  allPersons: Person[]; // To check for duplicate mobile numbers
}

const PersonForm: React.FC<PersonFormProps> = ({ onSave, initialData, onCancel, allPersons }) => {
  const [name, setName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [address, setAddress] = useState('');
  const [shopName, setShopName] = useState('');
  const [mobileError, setMobileError] = useState<string>('');

  useEffect(() => {
    if (initialData) {
      setName(initialData.name);
      setMobileNumber(initialData.mobileNumber || '');
      setAddress(initialData.address || '');
      setShopName(initialData.shopName || '');
    } else {
      setName('');
      setMobileNumber('');
      setAddress('');
      setShopName('');
    }
    setMobileError(''); // Reset error when initialData changes
  }, [initialData]);

  useEffect(() => {
    if (!mobileNumber.trim()) {
      setMobileError('');
      return;
    }

    const trimmedMobile = mobileNumber.trim();
    const duplicatePersons = allPersons.filter(p =>
      p.mobileNumber === trimmedMobile &&
      (!initialData || p.id !== initialData.id) // Exclude self if editing
    );

    if (duplicatePersons.length > 0) {
      const personNames = duplicatePersons.map(p => p.name).join(', ');
      setMobileError(
        BN_UI_TEXT.MOBILE_NUMBER_DUPLICATE
          .replace('{mobileNumber}', trimmedMobile)
          .replace('{personNamesString}', personNames)
      );
    } else {
      setMobileError('');
    }
  }, [mobileNumber, allPersons, initialData]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert(BN_UI_TEXT.NAME + " আবশ্যক।"); // Name is required
      return;
    }
    if (mobileError) {
      alert(mobileError);
      return;
    }
    onSave({
      name,
      mobileNumber: mobileNumber.trim() || undefined,
      address: address.trim() || undefined,
      shopName: shopName.trim() || undefined,
    }, initialData?.id);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div>
        <label htmlFor="person-name" className="block text-sm font-medium text-slate-600 mb-1">
          {BN_UI_TEXT.NAME} <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          id="person-name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder={BN_UI_TEXT.NAME_PLACEHOLDER}
          className="w-full px-4 py-2 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500"
          required
        />
      </div>
      <div>
        <label htmlFor="person-mobile" className="block text-sm font-medium text-slate-600 mb-1">
          {BN_UI_TEXT.PERSON_MOBILE_NUMBER}
        </label>
        <input
          type="tel"
          id="person-mobile"
          value={mobileNumber}
          onChange={(e) => setMobileNumber(e.target.value)}
          placeholder={BN_UI_TEXT.PERSON_MOBILE_PLACEHOLDER}
          className={`w-full px-4 py-2 border rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500 ${mobileError ? 'border-red-500' : 'border-slate-300'}`}
          aria-describedby="mobile-error"
        />
        {mobileError && (
          <p id="mobile-error" className="mt-1 text-xs text-red-600">
            {mobileError}
          </p>
        )}
      </div>
      <div>
        <label htmlFor="person-address" className="block text-sm font-medium text-slate-600 mb-1">
          {BN_UI_TEXT.PERSON_ADDRESS}
        </label>
        <textarea
          id="person-address"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder={BN_UI_TEXT.PERSON_ADDRESS_PLACEHOLDER}
          rows={2}
          className="w-full px-4 py-2 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500"
        />
      </div>
      <div>
        <label htmlFor="person-shopName" className="block text-sm font-medium text-slate-600 mb-1">
          {BN_UI_TEXT.PERSON_SHOP_NAME}
        </label>
        <input
          type="text"
          id="person-shopName"
          value={shopName}
          onChange={(e) => setShopName(e.target.value)}
          placeholder={BN_UI_TEXT.PERSON_SHOP_NAME_PLACEHOLDER}
          className="w-full px-4 py-2 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500"
        />
      </div>
      <div className="flex justify-end space-x-3 pt-3">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-slate-400"
        >
          {BN_UI_TEXT.CANCEL}
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 disabled:opacity-70"
          disabled={!!mobileError}
        >
          {initialData ? BN_UI_TEXT.SAVE_CHANGES : BN_UI_TEXT.SAVE_PERSON_BTN}
        </button>
      </div>
    </form>
  );
};

export default PersonForm;