
import React, { useState, useEffect } from 'react';
import { BN_UI_TEXT } from '../constants';
import EditIcon from './icons/EditIcon';
import TrashIcon from './icons/TrashIcon';
import PlusCircleIcon from './icons/PlusCircleIcon';

interface ManageSuggestionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  userSuggestions: string[];
  predefinedSuggestions: string[]; // To display them as well (read-only)
  onAddSuggestion: (suggestion: string) => void;
  onEditSuggestion: (oldSuggestion: string, newSuggestion: string) => void;
  onDeleteSuggestion: (suggestion: string) => void;
}

const ManageSuggestionsModal: React.FC<ManageSuggestionsModalProps> = ({
  isOpen,
  onClose,
  userSuggestions,
  predefinedSuggestions,
  onAddSuggestion,
  onEditSuggestion,
  onDeleteSuggestion,
}) => {
  const [newSuggestion, setNewSuggestion] = useState('');
  const [editingSuggestion, setEditingSuggestion] = useState<{ old: string; current: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setNewSuggestion('');
      setEditingSuggestion(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newSuggestion.trim()) {
      onAddSuggestion(newSuggestion.trim());
      setNewSuggestion('');
    }
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSuggestion && editingSuggestion.current.trim()) {
      onEditSuggestion(editingSuggestion.old, editingSuggestion.current.trim());
      setEditingSuggestion(null);
    }
  };

  const startEdit = (suggestion: string) => {
    setEditingSuggestion({ old: suggestion, current: suggestion });
  };

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-[100]" // Ensure highest z-index
      role="dialog"
      aria-modal="true"
      aria-labelledby="manage-suggestions-modal-title"
      onClick={onClose}
    >
      <div
        className="bg-white p-5 sm:p-6 rounded-xl shadow-2xl w-full max-w-xl max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-200">
          <h2 id="manage-suggestions-modal-title" className="text-xl font-semibold text-slate-800">
            {BN_UI_TEXT.MANAGE_SUGGESTIONS_MODAL_TITLE}
          </h2>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-slate-700 p-1 rounded-full"
            aria-label={BN_UI_TEXT.CLOSE_BTN}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Edit Suggestion Form (Modal within Modal concept or inline form) */}
        {editingSuggestion && (
          <div className="mb-6 p-4 border border-teal-300 bg-teal-50 rounded-lg">
            <h3 className="text-md font-medium text-teal-700 mb-2">{BN_UI_TEXT.EDIT_SUGGESTION_MODAL_TITLE}</h3>
            <form onSubmit={handleEditSubmit} className="flex items-center space-x-2">
              <input
                type="text"
                value={editingSuggestion.current}
                onChange={(e) => setEditingSuggestion({ ...editingSuggestion, current: e.target.value })}
                className="flex-grow px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500 text-sm"
                autoFocus
              />
              <button type="submit" className="bg-teal-600 hover:bg-teal-700 text-white font-medium py-2 px-3 rounded-md text-sm">
                {BN_UI_TEXT.SAVE_CHANGES}
              </button>
              <button type="button" onClick={() => setEditingSuggestion(null)} className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-medium py-2 px-3 rounded-md text-sm">
                {BN_UI_TEXT.CANCEL}
              </button>
            </form>
          </div>
        )}

        {/* Add New Suggestion Form */}
        {!editingSuggestion && (
            <form onSubmit={handleAddSubmit} className="mb-6 p-4 border border-slate-200 bg-slate-50 rounded-lg">
                <label htmlFor="new-suggestion" className="block text-sm font-medium text-slate-700 mb-1">
                {BN_UI_TEXT.ADD_NEW_SUGGESTION_LABEL}
                </label>
                <div className="flex items-center space-x-2">
                <input
                    type="text"
                    id="new-suggestion"
                    value={newSuggestion}
                    onChange={(e) => setNewSuggestion(e.target.value)}
                    placeholder={BN_UI_TEXT.SUGGESTION_PLACEHOLDER}
                    className="flex-grow px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-sm"
                />
                <button
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-medium py-2 px-4 rounded-md text-sm flex items-center space-x-1.5"
                >
                    <PlusCircleIcon className="w-4 h-4" />
                    <span>{BN_UI_TEXT.ADD_SUGGESTION_BTN}</span>
                </button>
                </div>
            </form>
        )}


        <div className="overflow-y-auto flex-grow custom-scrollbar-modal pr-1 space-y-6">
          {/* User Custom Suggestions */}
          <section>
            <h3 className="text-md font-semibold text-indigo-700 mb-2">{BN_UI_TEXT.USER_SUGGESTIONS_TITLE}</h3>
            {userSuggestions.length === 0 ? (
              <p className="text-sm text-slate-500 italic">{BN_UI_TEXT.NO_USER_SUGGESTIONS}</p>
            ) : (
              <ul className="space-y-1.5">
                {userSuggestions.map((suggestion) => (
                  <li key={suggestion} className="flex justify-between items-center p-2 bg-indigo-50 rounded-md border border-indigo-100 group">
                    <span className="text-sm text-slate-700">{suggestion}</span>
                    <div className="space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => startEdit(suggestion)}
                        className="p-1 text-blue-600 hover:text-blue-800"
                        title={BN_UI_TEXT.EDIT_SUGGESTION_TOOLTIP}
                      >
                        <EditIcon className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => onDeleteSuggestion(suggestion)}
                        className="p-1 text-red-500 hover:text-red-700"
                        title={BN_UI_TEXT.DELETE_SUGGESTION_TOOLTIP}
                      >
                        <TrashIcon className="w-4 h-4" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>

          {/* Predefined Suggestions (Read-only) */}
          <section>
            <h3 className="text-md font-semibold text-slate-600 mb-2">{BN_UI_TEXT.PREDEFINED_SUGGESTIONS_TITLE}</h3>
            {predefinedSuggestions.length === 0 ? (
              <p className="text-sm text-slate-500 italic">কোনো পূর্বনির্ধারিত পরামর্শ নেই।</p>
            ) : (
              <ul className="space-y-1.5 max-h-48 overflow-y-auto custom-scrollbar-modal pr-1 border-t border-b border-slate-200 py-2">
                {predefinedSuggestions.map((suggestion) => (
                  <li key={suggestion} className="p-1.5 bg-slate-100 rounded-md">
                    <span className="text-xs text-slate-600">{suggestion}</span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        <div className="mt-6 pt-4 text-right border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 text-sm font-medium text-white bg-slate-600 hover:bg-slate-700 rounded-lg shadow-md"
          >
            {BN_UI_TEXT.CLOSE_BTN}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ManageSuggestionsModal;
