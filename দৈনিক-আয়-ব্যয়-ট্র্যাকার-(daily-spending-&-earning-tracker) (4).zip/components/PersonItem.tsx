


import React from 'react';
import { Person } from '../types';
import { BN_UI_TEXT } from '../constants';
import TrashIcon from './icons/TrashIcon';
import EditIcon from './icons/EditIcon';
import HistoryIcon from './icons/HistoryIcon';
import ListBulletIcon from './icons/ListBulletIcon';
import LedgerIcon from './icons/LedgerIcon'; 

interface PersonItemProps {
  person: Person;
  netLedgerBalance?: number; 
  onEdit: (person: Person) => void;
  onDelete: (personId: string) => void;
  onViewHistory: (person: Person) => void;
  onViewPersonDebtsHistory: (person: Person) => void;
  onViewPersonLedger: (person: Person) => void; 
}

const PersonItem: React.FC<PersonItemProps> = ({ 
  person, 
  netLedgerBalance, 
  onEdit, 
  onDelete, 
  onViewHistory, 
  onViewPersonDebtsHistory,
  onViewPersonLedger 
}) => {
  const formatDate = (dateString?: string) => {
    if (!dateString) return 'N/A';
    try {
      return new Date(dateString).toLocaleDateString('bn-BD', {
        day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit'
      });
    } catch (e) { return dateString; }
  };

  const formatCurrency = (num: number): string => 
    `${BN_UI_TEXT.BDT_SYMBOL} ${Math.abs(num).toLocaleString('bn-BD', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const getBalanceStatusText = (balance: number): string => {
    if (balance > 0) return BN_UI_TEXT.LEDGER_BALANCE_STATUS_DEBIT.replace("{amount}", formatCurrency(balance)); 
    if (balance < 0) return BN_UI_TEXT.LEDGER_BALANCE_STATUS_CREDIT.replace("{amount}", formatCurrency(balance)); 
    return BN_UI_TEXT.LEDGER_BALANCE_STATUS_ZERO;
  };
  
  const getBalanceColorClass = (balance: number): string => {
    if (balance > 0) return 'text-green-600'; 
    if (balance < 0) return 'text-red-600';   
    return 'text-slate-700'; 
  };

  const nameClass = 'text-sky-700';
  const itemClass = '';
  const borderColorClass = 'border-sky-500';

  return (
    <li className={`bg-white p-4 rounded-lg shadow-sm border-l-4 ${borderColorClass} hover:shadow-md transition-shadow duration-150 ${itemClass}`}>
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div className="mb-3 sm:mb-0 flex-grow">
          <h3 className={`text-lg font-semibold ${nameClass}`}>{person.name}</h3>
          {person.mobileNumber && (
            <p className={`text-sm text-slate-600`}>
              {BN_UI_TEXT.PERSON_MOBILE_NUMBER}: {person.mobileNumber}
            </p>
          )}
          {person.shopName && (
            <p className={`text-sm text-slate-500`}>
              {BN_UI_TEXT.PERSON_SHOP_NAME}: {person.shopName}
            </p>
          )}
           {person.address && (
            <p className={`text-xs text-slate-500 truncate max-w-xs sm:max-w-sm md:max-w-md`} title={person.address}>
              {BN_UI_TEXT.PERSON_ADDRESS}: {person.address}
            </p>
          )}
          {typeof netLedgerBalance === 'number' && (
            <p className={`text-sm font-medium mt-1.5 ${getBalanceColorClass(netLedgerBalance)}`}>
              <span className="text-slate-600 font-normal">{BN_UI_TEXT.CURRENT_NET_LEDGER_BALANCE_LABEL}: </span>
              {getBalanceStatusText(netLedgerBalance)}
            </p>
          )}
        </div>
        <div className="flex items-center space-x-1 self-end sm:self-center flex-shrink-0">
          <button
            onClick={() => onViewPersonLedger(person)}
            className="text-slate-500 hover:text-indigo-600 p-2 rounded-full hover:bg-indigo-50 transition duration-150"
            title={BN_UI_TEXT.VIEW_PERSON_LEDGER_TOOLTIP}
            aria-label={BN_UI_TEXT.VIEW_PERSON_LEDGER_TOOLTIP}
          >
            <LedgerIcon className="w-4 h-4" />
          </button>
          <button
            onClick={() => onViewPersonDebtsHistory(person)}
            className="text-slate-500 hover:text-green-600 p-2 rounded-full hover:bg-green-50 transition duration-150"
            title={BN_UI_TEXT.VIEW_PERSON_DEBTS_HISTORY_TOOLTIP}
            aria-label={BN_UI_TEXT.VIEW_PERSON_DEBTS_HISTORY_TOOLTIP}
          >
            <ListBulletIcon className="w-4 h-4" />
          </button>
          <button
            onClick={() => onViewHistory(person)}
            className="text-slate-500 hover:text-sky-600 p-2 rounded-full hover:bg-sky-50 transition duration-150"
            title={BN_UI_TEXT.VIEW_HISTORY_TOOLTIP}
             aria-label={BN_UI_TEXT.VIEW_HISTORY_TOOLTIP}
          >
            <HistoryIcon className="w-4 h-4" />
          </button>
          <button
            onClick={() => onEdit(person)}
            className="text-slate-500 hover:text-blue-600 p-2 rounded-full hover:bg-blue-50 transition duration-150"
            title={BN_UI_TEXT.EDIT_PERSON_BTN_LABEL}
            aria-label={BN_UI_TEXT.EDIT_PERSON_BTN_LABEL}
          >
            <EditIcon className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(person.id)}
            className="text-slate-500 hover:text-red-600 p-2 rounded-full hover:bg-red-50 transition duration-150"
            title={BN_UI_TEXT.DELETE_PERSON_BTN_LABEL}
            aria-label={BN_UI_TEXT.DELETE_PERSON_BTN_LABEL}
          >
            <TrashIcon className="w-4 h-4" />
          </button>
        </div>
      </div>
      <div className="mt-2 pt-2 border-t border-slate-100 text-xs text-slate-400">
        <p>{BN_UI_TEXT.CREATED_ON} {formatDate(person.createdAt)}</p>
        {person.lastModified !== person.createdAt && (
        <p>{BN_UI_TEXT.LAST_MODIFIED_ON} {formatDate(person.lastModified)}</p>
        )}
      </div>
    </li>
  );
};

export default PersonItem;