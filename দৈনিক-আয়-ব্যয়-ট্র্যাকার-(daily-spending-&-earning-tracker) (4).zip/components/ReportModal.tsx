


import React, { useState, useEffect } from 'react';
import { Transaction, TransactionType } from '../types';
import { BN_UI_TEXT } from '../constants';
import TransactionItem from './TransactionItem'; 

interface ReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[]; 
  onDeleteTransaction: (id: string) => void;
  onEditTransaction: (transaction: Transaction) => void;
  onViewHistory: (transaction: Transaction) => void;
}

const ReportModal: React.FC<ReportModalProps> = ({ 
  isOpen, 
  onClose, 
  transactions,
  onDeleteTransaction,
  onEditTransaction,
  onViewHistory
}) => {
  const today = new Date();
  const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

  const [startDate, setStartDate] = useState(firstDayOfMonth.toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(today.toISOString().split('T')[0]);
  const [reportData, setReportData] = useState<{
    filteredTransactions: Transaction[];
    totalIncome: number;
    totalExpense: number;
    netBalance: number;
  } | null>(null);

  const handleGenerateReport = () => {
    if (!startDate || !endDate) {
      alert("অনুগ্রহ করে শুরুর এবং শেষের তারিখ নির্বাচন করুন।");
      return;
    }
    const start = new Date(startDate);
    start.setHours(0, 0, 0, 0); 
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999); 

    const filtered = transactions.filter(t => { // Use all transactions, no isDeleted filter
      const tDate = new Date(t.date);
      return tDate >= start && tDate <= end;
    });

    let income = 0;
    let expense = 0;
    filtered.forEach(t => {
      if (t.type === TransactionType.INCOME) income += t.amount;
      else expense += t.amount;
    });

    setReportData({
      filteredTransactions: filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
      totalIncome: income,
      totalExpense: expense,
      netBalance: income - expense,
    });
  };
  
  useEffect(() => {
    if (isOpen) {
      handleGenerateReport();
    } else {
      setReportData(null); 
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]); 

  if (!isOpen) return null;

  const formatDisplayDate = (dateString: string): string => {
    try {
        return new Date(dateString).toLocaleDateString('bn-BD', { day: '2-digit', month: 'long', year: 'numeric'});
    } catch { return dateString; }
  }

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-[98]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="report-modal-title"
      onClick={onClose}
    >
      <div
        className="bg-white p-5 sm:p-6 rounded-xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4 pb-3 border-b border-slate-200">
          <h2 id="report-modal-title" className="text-xl font-semibold text-slate-800">
            {BN_UI_TEXT.REPORT_MODAL_TITLE}
          </h2>
          <button
            onClick={onClose}
            className="text-slate-500 hover:text-slate-700 p-1 rounded-full"
            aria-label={BN_UI_TEXT.CLOSE_BTN}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="mb-5 p-4 bg-slate-50 rounded-lg border border-slate-200">
          <h3 className="text-md font-medium text-slate-700 mb-3">{BN_UI_TEXT.SELECT_DATE_RANGE}</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
            <div>
              <label htmlFor="report-start-date" className="block text-xs font-medium text-slate-600 mb-1">{BN_UI_TEXT.START_DATE}</label>
              <input
                type="date"
                id="report-start-date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500 text-sm"
              />
            </div>
            <div>
              <label htmlFor="report-end-date" className="block text-xs font-medium text-slate-600 mb-1">{BN_UI_TEXT.END_DATE}</label>
              <input
                type="date"
                id="report-end-date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500 text-sm"
              />
            </div>
            <button
              onClick={handleGenerateReport}
              className="w-full sm:w-auto bg-teal-600 hover:bg-teal-700 text-white font-semibold py-2.5 px-4 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm"
            >
              {BN_UI_TEXT.GENERATE_REPORT_BTN}
            </button>
          </div>
        </div>

        <div className="overflow-y-auto flex-grow custom-scrollbar-modal pr-1">
          {reportData ? (
            <>
              <div className="mb-4 p-3 bg-sky-50 rounded-lg border border-sky-200">
                <p className="text-sm text-slate-700 font-medium">
                  {BN_UI_TEXT.REPORT_FOR_PERIOD} {formatDisplayDate(startDate)} {BN_UI_TEXT.TO_DATE} {formatDisplayDate(endDate)}
                </p>
                <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-2 text-center sm:text-left">
                  <p className="text-sm"><span className="font-medium">{BN_UI_TEXT.TOTAL_INCOME}:</span> <span className="text-green-600 font-semibold">{BN_UI_TEXT.BDT_SYMBOL} {reportData.totalIncome.toLocaleString('bn-BD', {minimumFractionDigits: 2})}</span></p>
                  <p className="text-sm"><span className="font-medium">{BN_UI_TEXT.TOTAL_EXPENSE}:</span> <span className="text-red-600 font-semibold">{BN_UI_TEXT.BDT_SYMBOL} {reportData.totalExpense.toLocaleString('bn-BD', {minimumFractionDigits: 2})}</span></p>
                  <p className="text-sm"><span className="font-medium">{BN_UI_TEXT.NET_BALANCE_FOR_PERIOD}:</span> <span className={`${reportData.netBalance >= 0 ? 'text-sky-600' : 'text-orange-600'} font-semibold`}>{BN_UI_TEXT.BDT_SYMBOL} {reportData.netBalance.toLocaleString('bn-BD', {minimumFractionDigits: 2})}</span></p>
                </div>
              </div>

              {reportData.filteredTransactions.length === 0 ? (
                <p className="text-slate-500 text-center py-6">{BN_UI_TEXT.NO_TRANSACTIONS_IN_RANGE}</p>
              ) : (
                <ul className="space-y-3">
                  {reportData.filteredTransactions.map(transaction => (
                    <TransactionItem
                      key={transaction.id}
                      transaction={transaction}
                      onDeleteTransaction={onDeleteTransaction}
                      onEditTransaction={onEditTransaction}
                      onViewHistory={onViewHistory}
                    />
                  ))}
                </ul>
              )}
            </>
          ) : (
            <p className="text-slate-400 text-center py-6 italic">রিপোর্ট তৈরি করতে তারিখ নির্বাচন করে "জেনারেট করুন" বাটনে ক্লিক করুন।</p>
          )}
        </div>

        <div className="mt-6 pt-4 text-right border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 text-sm font-medium text-white bg-slate-700 hover:bg-slate-800 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-slate-500"
          >
            {BN_UI_TEXT.CLOSE_BTN}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReportModal;