
import React, { useState, FormEvent, useEffect, useRef } from 'react';
import { BN_UI_TEXT } from '../constants';
import { useAuth } from '../contexts/AuthContext';
import { AuthFormMode } from '../types'; 
import ExclamationCircleIcon from './icons/ExclamationCircleIcon';

interface AuthFormProps {
  mode: AuthFormMode; 
  onClose: () => void;
  onSwitchMode: (newMode: AuthFormMode) => void;
}

const AuthForm: React.FC<AuthFormProps> = ({ mode, onClose, onSwitchMode }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState(''); 
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [formMessage, setFormMessage] = useState<string | null>(null); 

  const { 
    login, 
    signup, 
    isAuthLoading, 
    authError, 
    clearAuthError, 
    currentUser,
    requestPasswordResetCode,
    resetPasswordWithCode
  } = useAuth();

  const prevModeRef = useRef<AuthFormMode | null>(null);

  useEffect(() => {
    clearAuthError();
    setFormMessage(null);

    const preserveEmailForForgotPassword =
      mode === 'forgotPasswordRequest' &&
      (prevModeRef.current === 'login' || prevModeRef.current === 'signup');
    
    const preserveEmailForResetPassword = mode === 'forgotPasswordReset' && prevModeRef.current === 'forgotPasswordRequest';

    if (!preserveEmailForForgotPassword && !preserveEmailForResetPassword) {
        setEmail('');
    }

    if (mode !== 'forgotPasswordReset') {
      setResetCode('');
      setNewPassword('');
      setConfirmNewPassword('');
    }
    if (mode !== 'signup') {
      setName('');
    }
    if (mode !== 'login' && mode !== 'forgotPasswordReset') {
      setPassword('');
    }

    prevModeRef.current = mode;
  }, [mode, clearAuthError]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    clearAuthError(); 
    setFormMessage(null);

    if (mode === 'login') {
      await login(email, password);
    } else if (mode === 'signup') {
      if (!name.trim()) {
        setFormMessage(BN_UI_TEXT.NAME + " প্রয়োজন।"); 
        return;
      }
      if (password.length < 6) {
        setFormMessage(BN_UI_TEXT.NEW_PASSWORD_LABEL);
        return;
      }
      await signup(name, email, password);
    } else if (mode === 'forgotPasswordRequest') {
      try {
        await requestPasswordResetCode(email);
        setFormMessage(BN_UI_TEXT.RESET_CODE_SENT_SUCCESS);
        onSwitchMode('forgotPasswordReset'); 
      } catch (err: any) {
        // authError will be set by AuthContext
      }
    } else if (mode === 'forgotPasswordReset') {
      if (newPassword !== confirmNewPassword) {
        setFormMessage(BN_UI_TEXT.PASSWORDS_DONT_MATCH);
        return;
      }
      if (newPassword.length < 6) {
        setFormMessage(BN_UI_TEXT.NEW_PASSWORD_LABEL + " কমপক্ষে ৬ অক্ষরের হতে হবে।");
        return;
      }
      try {
        await resetPasswordWithCode(email, resetCode, newPassword);
        setFormMessage(BN_UI_TEXT.PASSWORD_RESET_SUCCESS);
        setTimeout(() => {
            onSwitchMode('login');
            setFormMessage(null); 
        }, 3000);
      } catch (err:any) {
        // authError will be set by AuthContext
      }
    }
  };
  
  useEffect(() => {
    if (currentUser && !authError && (mode === 'login' || mode === 'signup')) { 
      onClose();
    }
  }, [currentUser, onClose, authError, mode]);

  const renderTitle = () => {
    switch(mode) {
      case 'login': return BN_UI_TEXT.LOGIN;
      case 'signup': return BN_UI_TEXT.SIGNUP;
      case 'forgotPasswordRequest':
      case 'forgotPasswordReset':
        return BN_UI_TEXT.FORGOT_PASSWORD_TITLE;
      default: return '';
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-[100]">
      <div className="bg-white p-6 sm:p-8 rounded-lg shadow-2xl w-full max-w-md relative">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-slate-500 hover:text-slate-700 text-2xl font-bold"
          aria-label="Close"
        >
          &times;
        </button>
        <h2 className="text-2xl sm:text-3xl font-semibold text-slate-800 mb-4 text-center">
          {renderTitle()}
        </h2>
        
        {mode === 'forgotPasswordRequest' && (
            <p className="text-sm text-slate-600 mb-4 text-center">{BN_UI_TEXT.FORGOT_PASSWORD_INSTRUCTIONS}</p>
        )}

        {authError && (
          <div className="mb-4 p-3 bg-red-100 border-l-4 border-red-500 text-red-700 rounded-md text-sm flex items-start space-x-2" role="alert">
            <ExclamationCircleIcon className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <span>{authError}</span>
          </div>
        )}
        {formMessage && !authError && ( 
          <div className={`mb-4 p-3 rounded-md text-sm flex items-start space-x-2 ${
            formMessage === BN_UI_TEXT.PASSWORD_RESET_SUCCESS || formMessage === BN_UI_TEXT.RESET_CODE_SENT_SUCCESS ? 
            'bg-green-50 border-l-4 border-green-500 text-green-700' : 
            'bg-red-100 border-l-4 border-red-500 text-red-700'
          }`} role="status">
             <ExclamationCircleIcon className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                formMessage === BN_UI_TEXT.PASSWORD_RESET_SUCCESS || formMessage === BN_UI_TEXT.RESET_CODE_SENT_SUCCESS ? 'text-green-600' : 'text-red-600'
             }`} /> 
            <span>{formMessage}</span>
          </div>
        )}


        <form onSubmit={handleSubmit} className="space-y-5">
          {mode === 'signup' && (
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-600 mb-1">
                {BN_UI_TEXT.NAME}
              </label>
              <input
                type="text"
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={BN_UI_TEXT.NAME_PLACEHOLDER}
                className="w-full px-4 py-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500 transition duration-150"
                required
              />
            </div>
          )}

          {(mode === 'login' || mode === 'signup' || mode === 'forgotPasswordRequest' || mode === 'forgotPasswordReset') && (
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-600 mb-1">
                {BN_UI_TEXT.EMAIL}
              </label>
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={BN_UI_TEXT.EMAIL_PLACEHOLDER}
                className="w-full px-4 py-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500 transition duration-150"
                required
                readOnly={mode === 'forgotPasswordReset'} 
              />
            </div>
          )}

          {(mode === 'login' || mode === 'signup') && (
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-slate-600 mb-1">
                {BN_UI_TEXT.PASSWORD}
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={BN_UI_TEXT.PASSWORD_PLACEHOLDER}
                className="w-full px-4 py-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500 transition duration-150"
                required
                minLength={6}
              />
            </div>
          )}

          {mode === 'forgotPasswordReset' && (
            <>
              <div>
                <label htmlFor="resetCode" className="block text-sm font-medium text-slate-600 mb-1">
                  {BN_UI_TEXT.RESET_CODE_LABEL}
                </label>
                <input
                  type="text"
                  id="resetCode"
                  value={resetCode}
                  onChange={(e) => setResetCode(e.target.value)}
                  placeholder={BN_UI_TEXT.RESET_CODE_PLACEHOLDER}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500 transition duration-150"
                  required
                />
              </div>
              <div>
                <label htmlFor="newPassword" className="block text-sm font-medium text-slate-600 mb-1">
                  {BN_UI_TEXT.NEW_PASSWORD_LABEL}
                </label>
                <input
                  type="password"
                  id="newPassword"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder={BN_UI_TEXT.PASSWORD_PLACEHOLDER}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500 transition duration-150"
                  required
                  minLength={6}
                />
              </div>
              <div>
                <label htmlFor="confirmNewPassword" className="block text-sm font-medium text-slate-600 mb-1">
                  {BN_UI_TEXT.CONFIRM_NEW_PASSWORD_LABEL}
                </label>
                <input
                  type="password"
                  id="confirmNewPassword"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  placeholder={BN_UI_TEXT.PASSWORD_PLACEHOLDER}
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-lg shadow-sm focus:ring-teal-500 focus:border-teal-500 transition duration-150"
                  required
                  minLength={6}
                />
              </div>
            </>
          )}
          
          <button
            type="submit"
            disabled={isAuthLoading}
            className="w-full bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 px-4 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 transition duration-150 ease-in-out disabled:opacity-70"
          >
            {isAuthLoading ? BN_UI_TEXT.LOADING : 
              mode === 'login' ? BN_UI_TEXT.LOGIN :
              mode === 'signup' ? BN_UI_TEXT.SIGNUP :
              mode === 'forgotPasswordRequest' ? BN_UI_TEXT.SEND_RESET_CODE_BTN :
              BN_UI_TEXT.RESET_PASSWORD_BTN
            }
          </button>
        </form>

        <div className="mt-6 text-center">
          {mode === 'login' && (
            <>
              <button
                onClick={() => { clearAuthError(); onSwitchMode('forgotPasswordRequest'); }}
                className="text-xs text-sky-600 hover:text-sky-800 hover:underline mb-2 block w-full"
              >
                {BN_UI_TEXT.FORGOT_PASSWORD_LINK}
              </button>
              <button
                onClick={() => { clearAuthError(); onSwitchMode('signup'); }}
                className="text-sm text-teal-600 hover:text-teal-800 hover:underline"
              >
                {BN_UI_TEXT.DONT_HAVE_ACCOUNT} {BN_UI_TEXT.SIGNUP}
              </button>
            </>
          )}
          {mode === 'signup' && (
            <button
              onClick={() => { clearAuthError(); onSwitchMode('login'); }}
              className="text-sm text-teal-600 hover:text-teal-800 hover:underline"
            >
              {BN_UI_TEXT.ALREADY_HAVE_ACCOUNT} {BN_UI_TEXT.LOGIN}
            </button>
          )}
          {(mode === 'forgotPasswordRequest' || mode === 'forgotPasswordReset') && (
            <button
              onClick={() => { clearAuthError(); onSwitchMode('login'); }}
              className="text-sm text-teal-600 hover:text-teal-800 hover:underline"
            >
              {BN_UI_TEXT.BACK_TO_LOGIN_LINK}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthForm;
