
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, AuthContextType } from '../types';
import { LOCAL_STORAGE_KEYS, BN_UI_TEXT } from '../constants';
import * as authService from '../services/authService';
import * as emailService from '../services/emailService';
import { initializeSharedTablesIfNeeded } from '../apiService';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);

  useEffect(() => {
    const initAuthAndTables = async () => {
      setIsAuthLoading(true);
      setAuthError(null);
      try {
        // Attempt to initialize tables first, regardless of user state.
        // This ensures tables are checked/created even if user is not logged in,
        // which is useful if 'users' table itself needs creation.
        await initializeSharedTablesIfNeeded();

        const storedUserJson = localStorage.getItem(LOCAL_STORAGE_KEYS.USER);
        if (storedUserJson) {
          const user: User = JSON.parse(storedUserJson);
          setCurrentUser(user);
          // Table initialization for a potentially logged-in user has already been attempted above.
          // If it failed, an error would have been thrown and caught.
        }
      } catch (error: any) {
        console.error("Error during initial auth and/or table setup:", error);
        setAuthError(`অ্যাপ্লিকেশন শুরু করতে সমস্যা হয়েছে: ${error.message}`);
      } finally {
        setIsAuthLoading(false);
      }
    };
    initAuthAndTables();
  }, []);

  const login = async (email: string, password: string) => {
    setIsAuthLoading(true);
    setAuthError(null);
    try {
      const user = await authService.loginUser(email, password);
      setCurrentUser(user);
      localStorage.setItem(LOCAL_STORAGE_KEYS.USER, JSON.stringify(user));
      await initializeSharedTablesIfNeeded(); // Ensure tables are ready for this user
      alert(BN_UI_TEXT.LOGIN_SUCCESS);
    } catch (error: any) {
      console.error("Login failed:", error);
      let errorMessage = error.message;
      if (error.message && error.message.includes("Initialization failed for table")) {
        errorMessage = `লগইন সফল হয়েছে, কিন্তু ডেটাবেস টেবিল সেটআপ করতে সমস্যা হয়েছে: ${error.message}`;
      }
      setAuthError(errorMessage);
      setCurrentUser(null); // Ensure user is cleared on login failure
    } finally {
      setIsAuthLoading(false);
    }
  };

  const signup = async (name: string, email: string, password: string) => {
    setIsAuthLoading(true);
    setAuthError(null);
    try {
      const newUser = await authService.signupUser(name, email, password);
      setCurrentUser(newUser);
      localStorage.setItem(LOCAL_STORAGE_KEYS.USER, JSON.stringify(newUser));
      
      await initializeSharedTablesIfNeeded(); // Ensure tables are ready for the new user

      try {
         await emailService.sendWelcomeEmail(newUser.email, newUser.name || newUser.email);
         alert(BN_UI_TEXT.SIGNUP_SUCCESS);
      } catch (emailError: any) {
        console.warn("Signup successful, but welcome email might have failed (check console for backend response):", emailError.message);
        alert(BN_UI_TEXT.SIGNUP_SUCCESS + " (তবে স্বাগতম ইমেইল পাঠাতে সমস্যা হতে পারে।)");
      }

    } catch (error: any) {
      console.error("Signup failed:", error);
      let errorMessage = error.message;
      if (error.message && error.message.includes("Initialization failed for table")) {
        errorMessage = `সাইনআপ সফল হয়েছে, কিন্তু ডেটাবেস টেবিল সেটআপ করতে সমস্যা হয়েছে: ${error.message}`;
      }
      setAuthError(errorMessage);
      setCurrentUser(null); // Ensure user is cleared on signup failure
    } finally {
      setIsAuthLoading(false);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem(LOCAL_STORAGE_KEYS.USER);
    alert(BN_UI_TEXT.LOGOUT_SUCCESS);
    setIsAuthLoading(false); // Reset loading state on logout
    setAuthError(null); // Clear any existing auth errors
  };
  
  const clearAuthError = () => {
    setAuthError(null);
  };

  const requestPasswordResetCode = async (email: string) => {
    setIsAuthLoading(true);
    setAuthError(null);
    try {
      await authService.requestPasswordResetCode(email);
      alert(BN_UI_TEXT.RESET_CODE_SENT_SUCCESS);
    } catch (error: any) {
      console.error("Request password reset code failed:", error);
      setAuthError(error.message || BN_UI_TEXT.RESET_CODE_SENT_FAIL);
      throw error; 
    } finally {
      setIsAuthLoading(false);
    }
  };

  const resetPasswordWithCode = async (email: string, code: string, newPassword: string) => {
    setIsAuthLoading(true);
    setAuthError(null);
    try {
      await authService.resetPasswordWithCode(email, code, newPassword);
      alert(BN_UI_TEXT.PASSWORD_RESET_SUCCESS);
    } catch (error: any) {
      console.error("Reset password failed:", error);
      setAuthError(error.message || BN_UI_TEXT.AUTH_ERROR_GENERAL);
      throw error; 
    } finally {
      setIsAuthLoading(false);
    }
  };


  return (
    <AuthContext.Provider value={{ 
      currentUser, 
      isAuthLoading, 
      authError, 
      login, 
      signup, 
      logout, 
      clearAuthError,
      requestPasswordResetCode,
      resetPasswordWithCode
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
