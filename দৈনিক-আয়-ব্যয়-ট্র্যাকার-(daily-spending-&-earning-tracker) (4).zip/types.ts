
export enum TransactionType {
  INCOME = 'INCOME',
  EXPENSE = 'EXPENSE',
}

export interface TransactionVersion {
  timestamp: string;
  action: 'created' | 'updated' | 'deleted' | 'restored'; 
  userId: string;
  snapshot: Omit<Transaction, 'id' | 'userId' | 'editHistory' | 'lastModified' | 'originalDate' | 'date' | 'description' | 'amount' | 'type' | 'linkedLedgerEntryId' | 'isDeleted' | 'deletedAt'> & { 
    date: string;
    description: string;
    amount: number;
    type: TransactionType;
    originalDate?: string;
    linkedLedgerEntryId?: string;
    isDeleted?: boolean;
    deletedAt?: string;
  };
}

export interface Transaction {
  id: string;
  date: string; 
  description: string;
  amount: number;
  type: TransactionType;
  originalDate?: string; 
  lastModified?: string; 
  userId?: string; 
  editHistory: TransactionVersion[];
  linkedLedgerEntryId?: string;
  isDeleted?: boolean;
  deletedAt?: string; 
}

export type EditableTransaction = Omit<Transaction, 'id' | 'date' | 'editHistory' | 'lastModified' | 'linkedLedgerEntryId' | 'isDeleted' | 'deletedAt'> & { date: string };


export enum DebtType {
  PAYABLE = 'PAYABLE', 
  RECEIVABLE = 'RECEIVABLE', 
}

export interface PersonVersion {
  timestamp: string;
  action: 'created' | 'updated'; 
  userId: string;
  snapshot: {
    name: string;
    mobileNumber?: string;
    address?: string;
    shopName?: string;
  };
}

export interface Person {
  id: string;
  name: string;
  mobileNumber?: string;
  address?: string;
  shopName?: string;
  userId: string;
  createdAt: string;
  lastModified: string;
  editHistory: PersonVersion[];
}

export interface DebtVersion {
  timestamp: string;
  action: 'created' | 'updated'; 
  userId: string; 
  snapshot: { 
    personId: string;
    originalAmount: number;
    remainingAmount: number;
    description: string;
    type: DebtType;
    dueDate?: string;
    isSettled: boolean;
    creationDate: string; 
    settledDate?: string; 
  };
}


export interface Debt {
  id: string;
  personId: string;
  originalAmount: number;
  remainingAmount: number;
  description: string;
  type: DebtType;
  dueDate?: string; 
  isSettled: boolean;
  creationDate: string;
  settledDate?: string;
  userId?: string; 
  lastModified?: string; 
  editHistory: DebtVersion[]; 
}

// User Authentication
export interface User {
  id?: string; 
  email: string;
  name?: string; 
  hashed_password?: string; 
}

export type AuthFormMode = 'login' | 'signup' | 'forgotPasswordRequest' | 'forgotPasswordReset';

export interface AuthContextType {
  currentUser: User | null;
  isAuthLoading: boolean;
  authError: string | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  clearAuthError: () => void;
  requestPasswordResetCode: (email: string) => Promise<void>;
  resetPasswordWithCode: (email: string, code: string, newPassword: string) => Promise<void>;
}

// Person Ledger System
export enum PersonLedgerEntryType {
  DEBIT = 'DEBIT', 
  CREDIT = 'CREDIT', 
}

export interface PersonLedgerEntry {
  id: string;
  personId: string;
  userId: string;
  date: string; 
  type: PersonLedgerEntryType;
  amount: number; 
  description: string;
  balanceAfterEntry: number; 
}


export enum FormPurpose {
  CREATE_PAYABLE = 'createPayable',
  CREATE_RECEIVABLE = 'createReceivable',
  RECORD_PERSON_PAYMENT = 'recordPersonPayment', 
  RECORD_USER_PAYMENT_TO_PERSON = 'recordUserPaymentToPerson', 
}


export interface DebtFormSubmitData {
  personNameValue: string;
  explicitSelectedPersonId?: string | null;
  amount: number; 
  description: string;
  formPurpose: FormPurpose;
  debtType?: DebtType; 
  dueDate?: string;    
  paymentDate?: string; 
}

// Budgeting Feature
export interface BudgetCategory {
  id: string;
  userId: string;
  name: string;
  createdAt: string;
  lastModified: string;
  associatedSuggestions: string[]; // New field for linked suggestions
  // icon?: string; // Future enhancement
}

export enum BudgetPeriod {
  MONTHLY = 'MONTHLY',
  // WEEKLY = 'WEEKLY', // Future enhancement
  // YEARLY = 'YEARLY', // Future enhancement
}

export interface Budget {
  id: string;
  userId: string;
  categoryId: string;
  amount: number; // Budgeted amount
  period: BudgetPeriod;
  startDate: string; // ISO date string, e.g., "2023-04-01" (always 1st for monthly)
  endDate: string; // ISO date string, e.g., "2023-04-30" (calculated last day of month)
  createdAt: string;
  lastModified: string;
}